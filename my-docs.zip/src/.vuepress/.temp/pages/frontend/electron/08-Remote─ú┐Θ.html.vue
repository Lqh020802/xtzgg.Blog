<template><div><h1 id="_08-remote模块-多窗口" tabindex="-1"><a class="header-anchor" href="#_08-remote模块-多窗口"><span>08. Remote模块-多窗口</span></a></h1>
<p>提示</p>
<p>Electron 中与 GUI 相关的模块只存在于主进程，而不在渲染进程中 ，为了能从渲染进程中使用它们，需要给主进程发送进程间消息。remote 模块提供了一种在渲染进程和主进程之间进行进程间通讯的简便途径，使用 remote 模块，可以调用主进程对象的方法，而无需显式地发送进程间消息，这类似于 Java 的 RMI。</p>
<p>注意</p>
<p>Electron10.x 以后要使用 remote 模块的必须得在 BrowserWindow 中开启。</p>
<p>例:</p>
<p><img src="/Electron/多窗口.jpg" alt="" loading="lazy"><br>
全部代码:</p>
<p>需要注意的是electron12之后的版本，需要加上</p>
<div class="language-text line-numbers-mode" data-highlighter="shiki" data-ext="text" style="--shiki-light:#383A42;--shiki-dark:#abb2bf;--shiki-light-bg:#FAFAFA;--shiki-dark-bg:#282c34"><pre class="shiki shiki-themes one-light one-dark-pro vp-code" v-pre=""><code class="language-text"><span class="line"><span>webPreferences:{</span></span>
<span class="line"><span>nodeIntegration: true,</span></span>
<span class="line"><span>contextIsolation:false,</span></span>
<span class="line"><span>// 开启remote</span></span>
<span class="line"><span>enableRemoteModule: true,</span></span>
<span class="line"><span>}</span></span></code></pre>
<div class="line-numbers" aria-hidden="true" style="counter-reset:line-number 0"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div></div></template>


