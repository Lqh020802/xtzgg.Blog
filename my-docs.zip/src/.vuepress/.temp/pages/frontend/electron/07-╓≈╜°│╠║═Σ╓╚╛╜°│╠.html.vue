<template><div><h1 id="_07-主进程和渲染进程" tabindex="-1"><a class="header-anchor" href="#_07-主进程和渲染进程"><span>07. 主进程和渲染进程</span></a></h1>
<p><code v-pre>package.json</code>中定义的入口文件就是主进程,一个<code v-pre>Electron</code>中只有一个主进程</p>
<p>我们可以利用一个主进程打开多个子进程</p>
<p><code v-pre>web</code>页面运行在自己的渲染进程中</p>
<p>一个主进程可以控制多个渲染进程</p>
<figure><img src="/Electron/主进程和渲染进程.jpg" alt="" tabindex="0" loading="lazy"><figcaption></figcaption></figure>
<p>一个小案例,帮助理解主进程和渲染进程完整代码</p>
<figure><img src="/Electron/案例01.jpg" alt="" tabindex="0" loading="lazy"><figcaption></figcaption></figure>
</div></template>


