<template><div><h1 id="_01-快速入门" tabindex="-1"><a class="header-anchor" href="#_01-快速入门"><span>01. 快速入门</span></a></h1>
<p>基本要求</p>
<p>在使用Electron开发前,需要安装<a href="https://nodejs.org/en/" target="_blank" rel="noopener noreferrer">Node.js</a>检查Node.js是否安装成功,可在终端输入以下命令:</p>
<p>node -v<br>
npm -v</p>
<div class="language- line-numbers-mode" data-highlighter="shiki" data-ext="" style="--shiki-light:#383A42;--shiki-dark:#abb2bf;--shiki-light-bg:#FAFAFA;--shiki-dark-bg:#282c34"><pre class="shiki shiki-themes one-light one-dark-pro vp-code" v-pre=""><code class="language-"><span class="line"><span></span></span>
<span class="line"><span>![查看node是否安装成功](/Electron/node.png)</span></span>
<span class="line"><span></span></span>
<span class="line"><span>输出版本信息,安装成功。</span></span>
<span class="line"><span></span></span>
<span class="line"><span>创建你的应用程序</span></span>
<span class="line"><span></span></span>
<span class="line"><span>使用脚手架创建</span></span>
<span class="line"><span></span></span>
<span class="line"><span>### 初始化 npm 包</span></span>
<span class="line"><span></span></span>
<span class="line"><span>输入命令后会出现一些[可选]配置,回车默认选择.</span></span>
<span class="line"><span></span></span>
<span class="line"><span>![初始化项目](/Electron/01.png)</span></span>
<span class="line"><span></span></span>
<span class="line"><span>会生成一个package.json文件.</span></span>
<span class="line"><span></span></span>
<span class="line"><span>![package.json](/Electron/02.jpg)</span></span>
<span class="line"><span></span></span>
<span class="line"><span>- **入口文件**main.js</span></span>
<span class="line"><span>- author 与 description 可为任意值，但对于应用打包是必填项。</span></span>
<span class="line"><span></span></span>
<span class="line"><span>### 安装Electron依赖</span></span>
<span class="line"><span></span></span>
<span class="line"><span>安装成功后,package.json  </span></span>
<span class="line"><span>devDependenciesz 中会出现Election版本号</span></span>
<span class="line"><span></span></span>
<span class="line"><span>![安装依赖](/Electron/03.jpg)</span></span>
<span class="line"><span></span></span>
<span class="line"><span>### 执行Electron程序</span></span>
<span class="line"><span></span></span>
<span class="line"><span>在执行`Electron`程序之前,需要在`package.json`中配置 scripts</span></span>
<span class="line"><span></span></span>
<span class="line"><span>```json</span></span>
<span class="line"><span>{</span></span>
<span class="line"><span>    "name": "my-electron-app",</span></span>
<span class="line"><span>    "version": "1.0.0",</span></span>
<span class="line"><span>     "description": "Hello World!",</span></span>
<span class="line"><span>     "main": "main.js",</span></span>
<span class="line"><span>     "author": "AirL",</span></span>
<span class="line"><span>     "license": "MIT",</span></span>
<span class="line"><span>     "devDependencies": {"electron": "^19.0.8"}</span></span>
<span class="line"><span>    "scripts":{"start":"electron ."}</span></span>
<span class="line"><span>}</span></span></code></pre>
<div class="line-numbers" aria-hidden="true" style="counter-reset:line-number 0"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><h3 id="将electron包安装到应用的开发依赖中。" tabindex="-1"><a class="header-anchor" href="#将electron包安装到应用的开发依赖中。"><span>将<code v-pre>electron</code>包安装到应用的开发依赖中。</span></a></h3>
<h3 id="执行electron" tabindex="-1"><a class="header-anchor" href="#执行electron"><span>执行Electron</span></a></h3>
<p>执行 Electron 需要在 package.json配置文件中的<code v-pre>scripts</code>字段下插入一条<code v-pre>start</code>命令</p>
<div class="language-json line-numbers-mode" data-highlighter="shiki" data-ext="json" style="--shiki-light:#383A42;--shiki-dark:#abb2bf;--shiki-light-bg:#FAFAFA;--shiki-dark-bg:#282c34"><pre class="shiki shiki-themes one-light one-dark-pro vp-code" v-pre=""><code class="language-json"><span class="line"><span style="--shiki-light:#383A42;--shiki-dark:#ABB2BF">{</span></span>
<span class="line"><span style="--shiki-light:#E45649;--shiki-dark:#E06C75">   "scripts"</span><span style="--shiki-light:#383A42;--shiki-dark:#ABB2BF">: {</span></span>
<span class="line"><span style="--shiki-light:#E45649;--shiki-dark:#E06C75">   "start"</span><span style="--shiki-light:#383A42;--shiki-dark:#ABB2BF">: </span><span style="--shiki-light:#50A14F;--shiki-dark:#98C379">"electron ."</span></span>
<span class="line"><span style="--shiki-light:#383A42;--shiki-dark:#ABB2BF"> }</span></span>
<span class="line"><span style="--shiki-light:#383A42;--shiki-dark:#ABB2BF">}</span></span></code></pre>
<div class="line-numbers" aria-hidden="true" style="counter-reset:line-number 0"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><figure><img src="/Electron/04.png" alt="配置scripts" tabindex="0" loading="lazy"><figcaption>配置scripts</figcaption></figure>
<h3 id="start-执行命令" tabindex="-1"><a class="header-anchor" href="#start-执行命令"><span>start 执行命令</span></a></h3>
<p>执行命令后会报一个错误!!</p>
<figure><img src="/Electron/05.jpg" alt="报错信息" tabindex="0" loading="lazy"><figcaption>报错信息</figcaption></figure>
<p>这是因为没有<code v-pre>main</code>主进程入口文件</p>
<p>继续</p>
<h3 id="运行主进程" tabindex="-1"><a class="header-anchor" href="#运行主进程"><span>运行主进程</span></a></h3>
<div class="hint-container tip">
<p class="hint-container-title">提示</p>
<p>任何 Electron 应用程序的入口都是 main 文件。 这个文件控制了主进程</p>
</div>
<p>在package.json中配置好 main 入口文件后</p>
<p>在 根目录下创建<code v-pre>main.js</code></p>
<figure><img src="/Electron/06.jpg" alt="创建main.js" tabindex="0" loading="lazy"><figcaption>创建main.js</figcaption></figure>
<p>在根目录下创建好main.js后</p>
<p>如果此时再次执行<code v-pre>npm start</code>程序此时虽然不会给我们报错,但是不会执行</p>
<p>因为此时<code v-pre>main.js</code>中还没有任何代码</p>
<h3 id="创建页面-index-html" tabindex="-1"><a class="header-anchor" href="#创建页面-index-html"><span>创建页面 index.html</span></a></h3>
<p>在Electron中，各个窗口显示的内容可以是本地HTML文件，也可以是一个远程url。</p>
<p>在根目录下创建一个<code v-pre>index.html</code></p>
<p>页面中输入 Hello World!</p>
<h3 id="在窗口中打开页面" tabindex="-1"><a class="header-anchor" href="#在窗口中打开页面"><span>在窗口中打开页面</span></a></h3>
<p>在使用<code v-pre>Electron</code>加载页面之前, 我们需要在<code v-pre>main.js</code>中引入两个模块</p>
<p><code v-pre>app</code>模块,它控制应用程序的事件生命周期</p>
<p><code v-pre>BrowserWindow</code>模块,它创建和管理应用程序窗口</p>
<div class="language-javascript line-numbers-mode" data-highlighter="shiki" data-ext="javascript" style="--shiki-light:#383A42;--shiki-dark:#abb2bf;--shiki-light-bg:#FAFAFA;--shiki-dark-bg:#282c34"><pre class="shiki shiki-themes one-light one-dark-pro vp-code" v-pre=""><code class="language-javascript"><span class="line"><span style="--shiki-light:#A626A4;--shiki-dark:#C678DD">   const</span><span style="--shiki-light:#383A42;--shiki-dark:#ABB2BF"> { </span><span style="--shiki-light:#986801;--shiki-dark:#E5C07B">app</span><span style="--shiki-light:#383A42;--shiki-dark:#ABB2BF">, </span><span style="--shiki-light:#986801;--shiki-dark:#E5C07B">BrowserWindow</span><span style="--shiki-light:#383A42;--shiki-dark:#ABB2BF"> } </span><span style="--shiki-light:#0184BC;--shiki-dark:#56B6C2">=</span><span style="--shiki-light:#4078F2;--shiki-dark:#61AFEF"> require</span><span style="--shiki-light:#383A42;--shiki-dark:#ABB2BF">(</span><span style="--shiki-light:#50A14F;--shiki-dark:#98C379">'electron'</span><span style="--shiki-light:#383A42;--shiki-dark:#ABB2BF">)</span></span></code></pre>
<div class="line-numbers" aria-hidden="true" style="counter-reset:line-number 0"><div class="line-number"></div></div></div><p>创建一个<code v-pre>createWindow()</code>方法来将<code v-pre>index.html</code>加载进入一个新的<code v-pre>BrowserWindow</code>实例</p>
<div class="language-javascript line-numbers-mode" data-highlighter="shiki" data-ext="javascript" style="--shiki-light:#383A42;--shiki-dark:#abb2bf;--shiki-light-bg:#FAFAFA;--shiki-dark-bg:#282c34"><pre class="shiki shiki-themes one-light one-dark-pro vp-code" v-pre=""><code class="language-javascript"><span class="line"><span style="--shiki-light:#A626A4;--shiki-dark:#C678DD">  const</span><span style="--shiki-light:#4078F2;--shiki-dark:#61AFEF"> createWindow</span><span style="--shiki-light:#0184BC;--shiki-dark:#56B6C2"> =</span><span style="--shiki-light:#383A42;--shiki-dark:#ABB2BF"> () </span><span style="--shiki-light:#A626A4;--shiki-dark:#C678DD">=></span><span style="--shiki-light:#383A42;--shiki-dark:#ABB2BF"> {</span></span>
<span class="line"><span style="--shiki-light:#A626A4;--shiki-dark:#C678DD">  const</span><span style="--shiki-light:#986801;--shiki-dark:#E5C07B"> win</span><span style="--shiki-light:#0184BC;--shiki-dark:#56B6C2"> =</span><span style="--shiki-light:#A626A4;--shiki-dark:#C678DD"> new</span><span style="--shiki-light:#4078F2;--shiki-dark:#61AFEF"> BrowserWindow</span><span style="--shiki-light:#383A42;--shiki-dark:#ABB2BF">({</span></span>
<span class="line"><span style="--shiki-light:#A0A1A7;--shiki-light-font-style:italic;--shiki-dark:#7F848E;--shiki-dark-font-style:italic">     /**</span></span>
<span class="line"><span style="--shiki-light:#A0A1A7;--shiki-light-font-style:italic;--shiki-dark:#7F848E;--shiki-dark-font-style:italic">      * width electron窗口 宽度</span></span>
<span class="line"><span style="--shiki-light:#A0A1A7;--shiki-light-font-style:italic;--shiki-dark:#7F848E;--shiki-dark-font-style:italic">      * height electron窗口 高度</span></span>
<span class="line"><span style="--shiki-light:#A0A1A7;--shiki-light-font-style:italic;--shiki-dark:#7F848E;--shiki-dark-font-style:italic">      */</span></span>
<span class="line"><span style="--shiki-light:#E45649;--shiki-dark:#E06C75">     width</span><span style="--shiki-light:#0184BC;--shiki-dark:#ABB2BF">:</span><span style="--shiki-light:#986801;--shiki-dark:#D19A66"> 600</span><span style="--shiki-light:#383A42;--shiki-dark:#ABB2BF">,  </span></span>
<span class="line"><span style="--shiki-light:#E45649;--shiki-dark:#E06C75">     height</span><span style="--shiki-light:#0184BC;--shiki-dark:#ABB2BF">:</span><span style="--shiki-light:#986801;--shiki-dark:#D19A66"> 400</span></span>
<span class="line"><span style="--shiki-light:#383A42;--shiki-dark:#ABB2BF"> })</span></span>
<span class="line"><span style="--shiki-light:#383A42;--shiki-dark:#E5C07B">     win</span><span style="--shiki-light:#383A42;--shiki-dark:#ABB2BF">.</span><span style="--shiki-light:#4078F2;--shiki-dark:#61AFEF">loadFile</span><span style="--shiki-light:#383A42;--shiki-dark:#ABB2BF">(</span><span style="--shiki-light:#50A14F;--shiki-dark:#98C379">'index.html'</span><span style="--shiki-light:#383A42;--shiki-dark:#ABB2BF">) </span><span style="--shiki-light:#A0A1A7;--shiki-light-font-style:italic;--shiki-dark:#7F848E;--shiki-dark-font-style:italic">// 加载网页</span></span>
<span class="line"><span style="--shiki-light:#383A42;--shiki-dark:#ABB2BF">}</span></span></code></pre>
<div class="line-numbers" aria-hidden="true" style="counter-reset:line-number 0"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><p>在<code v-pre>Electron</code>中, 只有在<code v-pre>app</code>的<code v-pre>ready</code>事件被触发才会创建浏览器窗口, 在执行命令之前,我们需要使用<code v-pre>app.whenReady()</code>Api来监听此事件,在whenReady()成功后调用<code v-pre>createWindow()</code>方法</p>
<div class="language-javascript line-numbers-mode" data-highlighter="shiki" data-ext="javascript" style="--shiki-light:#383A42;--shiki-dark:#abb2bf;--shiki-light-bg:#FAFAFA;--shiki-dark-bg:#282c34"><pre class="shiki shiki-themes one-light one-dark-pro vp-code" v-pre=""><code class="language-javascript"><span class="line"><span style="--shiki-light:#383A42;--shiki-dark:#E5C07B">app</span><span style="--shiki-light:#383A42;--shiki-dark:#ABB2BF">.</span><span style="--shiki-light:#4078F2;--shiki-dark:#61AFEF">whenReady</span><span style="--shiki-light:#383A42;--shiki-dark:#ABB2BF">().</span><span style="--shiki-light:#4078F2;--shiki-dark:#61AFEF">then</span><span style="--shiki-light:#383A42;--shiki-dark:#ABB2BF">(() </span><span style="--shiki-light:#A626A4;--shiki-dark:#C678DD">=></span><span style="--shiki-light:#383A42;--shiki-dark:#ABB2BF"> {</span></span>
<span class="line"><span style="--shiki-light:#4078F2;--shiki-dark:#61AFEF"> createWindow</span><span style="--shiki-light:#383A42;--shiki-dark:#ABB2BF">()</span></span>
<span class="line"><span style="--shiki-light:#383A42;--shiki-dark:#ABB2BF">})</span></span></code></pre>
<div class="line-numbers" aria-hidden="true" style="counter-reset:line-number 0"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><h3 id="运行-npm-start-或-yarn-start" tabindex="-1"><a class="header-anchor" href="#运行-npm-start-或-yarn-start"><span>运行 npm start 或 yarn start</span></a></h3>
<figure><img src="/Electron/07.jpg" alt="运行成功" tabindex="0" loading="lazy"><figcaption>运行成功</figcaption></figure>
<p>成功显示！</p>
</div></template>


