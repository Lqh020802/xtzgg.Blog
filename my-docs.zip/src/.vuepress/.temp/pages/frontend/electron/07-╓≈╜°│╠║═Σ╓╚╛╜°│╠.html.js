import comp from "D:/vue-theme-hope/my-docs/src/.vuepress/.temp/pages/frontend/electron/07-主进程和渲染进程.html.vue"
const data = JSON.parse("{\"path\":\"/frontend/electron/07-%E4%B8%BB%E8%BF%9B%E7%A8%8B%E5%92%8C%E6%B8%B2%E6%9F%93%E8%BF%9B%E7%A8%8B.html\",\"title\":\"07. 主进程和渲染进程\",\"lang\":\"zh-CN\",\"frontmatter\":{\"title\":\"07. 主进程和渲染进程\",\"icon\":\"simple-icons:electron\",\"description\":\"07. 主进程和渲染进程 package.json中定义的入口文件就是主进程,一个Electron中只有一个主进程 我们可以利用一个主进程打开多个子进程 web页面运行在自己的渲染进程中 一个主进程可以控制多个渲染进程 一个小案例,帮助理解主进程和渲染进程完整代码\"},\"readingTime\":{\"minutes\":0.43,\"words\":130},\"filePathRelative\":\"frontend/electron/07-主进程和渲染进程.md\",\"excerpt\":\"\\n<p><code>package.json</code>中定义的入口文件就是主进程,一个<code>Electron</code>中只有一个主进程</p>\\n<p>我们可以利用一个主进程打开多个子进程</p>\\n<p><code>web</code>页面运行在自己的渲染进程中</p>\\n<p>一个主进程可以控制多个渲染进程</p>\\n<figure><img src=\\\"/Electron/主进程和渲染进程.jpg\\\" alt=\\\"\\\" tabindex=\\\"0\\\" loading=\\\"lazy\\\"><figcaption></figcaption></figure>\\n<p>一个小案例,帮助理解主进程和渲染进程完整代码</p>\",\"autoDesc\":true}")
export { comp, data }

if (import.meta.webpackHot) {
  import.meta.webpackHot.accept()
  if (__VUE_HMR_RUNTIME__.updatePageData) {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  }
}

if (import.meta.hot) {
  import.meta.hot.accept(({ data }) => {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  })
}
