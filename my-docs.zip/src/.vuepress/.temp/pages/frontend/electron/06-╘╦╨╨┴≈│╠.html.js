import comp from "D:/vue-theme-hope/my-docs/src/.vuepress/.temp/pages/frontend/electron/06-运行流程.html.vue"
const data = JSON.parse("{\"path\":\"/frontend/electron/06-%E8%BF%90%E8%A1%8C%E6%B5%81%E7%A8%8B.html\",\"title\":\"06. 运行流程\",\"lang\":\"zh-CN\",\"frontmatter\":{\"title\":\"06. 运行流程\",\"icon\":\"simple-icons:electron\",\"description\":\"06. 运行流程 读取package.json中的入口文件,一般为main.js main.js主进程中创建渲染进程 读取应用页面的布局和样式 使用IPC在主进程执行任务并获取信息\"},\"readingTime\":{\"minutes\":0.28,\"words\":85},\"filePathRelative\":\"frontend/electron/06-运行流程.md\",\"excerpt\":\"\\n<figure><img src=\\\"/Electron/运行流程.jpg\\\" alt=\\\"\\\" tabindex=\\\"0\\\" loading=\\\"lazy\\\"><figcaption></figcaption></figure>\\n<ul>\\n<li>读取<code>package.json</code>中的入口文件,一般为<code>main.js</code></li>\\n</ul>\\n<figure><img src=\\\"/Electron/运行流程01.jpg\\\" alt=\\\"\\\" tabindex=\\\"0\\\" loading=\\\"lazy\\\"><figcaption></figcaption></figure>\\n<ul>\\n<li><strong>main.js</strong>主进程中创建渲染进程</li>\\n</ul>\",\"autoDesc\":true}")
export { comp, data }

if (import.meta.webpackHot) {
  import.meta.webpackHot.accept()
  if (__VUE_HMR_RUNTIME__.updatePageData) {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  }
}

if (import.meta.hot) {
  import.meta.hot.accept(({ data }) => {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  })
}
