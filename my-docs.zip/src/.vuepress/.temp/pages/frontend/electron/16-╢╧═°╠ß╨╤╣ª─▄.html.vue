<template><div><h1 id="_16-断网提醒功能" tabindex="-1"><a class="header-anchor" href="#_16-断网提醒功能"><span>16. 断网提醒功能</span></a></h1>
<p>断网提醒功能很简单,使用的是 window 的<code v-pre>onoffline</code>和<code v-pre>ononline</code>事件. 用来提醒用户网络已经断开或者网络已经连接上</p>
<div class="language-html line-numbers-mode" data-highlighter="shiki" data-ext="html" style="--shiki-light:#383A42;--shiki-dark:#abb2bf;--shiki-light-bg:#FAFAFA;--shiki-dark-bg:#282c34"><pre class="shiki shiki-themes one-light one-dark-pro vp-code" v-pre=""><code class="language-html"><span class="line"><span style="--shiki-light:#383A42;--shiki-dark:#ABB2BF"> &#x3C;</span><span style="--shiki-light:#E45649;--shiki-dark:#E06C75">h2</span><span style="--shiki-light:#383A42;--shiki-dark:#ABB2BF">>断网提醒功能&#x3C;/</span><span style="--shiki-light:#E45649;--shiki-dark:#E06C75">h2</span><span style="--shiki-light:#383A42;--shiki-dark:#ABB2BF">></span></span>
<span class="line"></span>
<span class="line"><span style="--shiki-light:#383A42;--shiki-dark:#ABB2BF">```javascript</span></span>
<span class="line"><span style="--shiki-light:#383A42;--shiki-dark:#ABB2BF"> window.addEventListener("online", () => {</span></span>
<span class="line"><span style="--shiki-light:#383A42;--shiki-dark:#ABB2BF">    alert("网络连接成功");</span></span>
<span class="line"><span style="--shiki-light:#383A42;--shiki-dark:#ABB2BF">});</span></span>
<span class="line"><span style="--shiki-light:#383A42;--shiki-dark:#ABB2BF">window.addEventListener("offline", () => {</span></span>
<span class="line"><span style="--shiki-light:#383A42;--shiki-dark:#ABB2BF">    alert("断网了,您的网络连接有问题哦,请检查网络");</span></span>
<span class="line"><span style="--shiki-light:#383A42;--shiki-dark:#ABB2BF">});</span></span></code></pre>
<div class="line-numbers" aria-hidden="true" style="counter-reset:line-number 0"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><p>断网网络</p>
<p><img src="/Electron/断开网络.jpg" alt="" loading="lazy"><br>
网络连接</p>
<figure><img src="/Electron/连接网络.jpg" alt="" tabindex="0" loading="lazy"><figcaption></figcaption></figure>
</div></template>


