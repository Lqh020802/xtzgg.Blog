<template><div><h1 id="_04-上下文隔离" tabindex="-1"><a class="header-anchor" href="#_04-上下文隔离"><span>04. 上下文隔离</span></a></h1>
<h3 id="上下文隔离是什么" tabindex="-1"><a class="header-anchor" href="#上下文隔离是什么"><span>上下文隔离是什么？</span></a></h3>
<p>上下文隔离功能将确保<code v-pre>预加载脚本</code>和<code v-pre>Electron</code>的内部逻辑 运行在所加载的<code v-pre>webcontent</code>网页 之外的另一个独立的上下文环境里。 这对安全性很重要，因为它有助于阻止网站访问<code v-pre>Electron</code>的内部组件 和<code v-pre>预加载脚本</code>可访问的高等级权限的API 。</p>
<p>这意味着，<code v-pre>预加载脚本</code>访问的<code v-pre>window</code>对象并不是网站所能访问的对象。</p>
<p>例如，在预加载脚本中设置<code v-pre>window.hello = 'wave'</code>并且启用了上下文隔离，当网站尝试访问<code v-pre>window.hello</code>对象时将返回<code v-pre>undefined</code>。</p>
<p>提示</p>
<p>自 Electron 12 以来，默认情况下已启用上下文隔离，并且它是 所有应用程序推荐的安全设置。</p>
</div></template>


