import comp from "D:/vue-theme-hope/my-docs/src/.vuepress/.temp/pages/frontend/electron/08-Remote模块.html.vue"
const data = JSON.parse("{\"path\":\"/frontend/electron/08-Remote%E6%A8%A1%E5%9D%97.html\",\"title\":\"08. Remote模块-多窗口\",\"lang\":\"zh-CN\",\"frontmatter\":{\"title\":\"08. Remote模块-多窗口\",\"icon\":\"simple-icons:electron\",\"description\":\"08. Remote模块-多窗口 提示 Electron 中与 GUI 相关的模块只存在于主进程，而不在渲染进程中 ，为了能从渲染进程中使用它们，需要给主进程发送进程间消息。remote 模块提供了一种在渲染进程和主进程之间进行进程间通讯的简便途径，使用 remote 模块，可以调用主进程对象的方法，而无需显式地发送进程间消息，这类似于 Java 的 ...\"},\"readingTime\":{\"minutes\":0.66,\"words\":197},\"filePathRelative\":\"frontend/electron/08-Remote模块.md\",\"excerpt\":\"\\n<p>提示</p>\\n<p>Electron 中与 GUI 相关的模块只存在于主进程，而不在渲染进程中 ，为了能从渲染进程中使用它们，需要给主进程发送进程间消息。remote 模块提供了一种在渲染进程和主进程之间进行进程间通讯的简便途径，使用 remote 模块，可以调用主进程对象的方法，而无需显式地发送进程间消息，这类似于 Java 的 RMI。</p>\\n<p>注意</p>\\n<p>Electron10.x 以后要使用 remote 模块的必须得在 BrowserWindow 中开启。</p>\\n<p>例:</p>\\n<p><img src=\\\"/Electron/多窗口.jpg\\\" alt=\\\"\\\" loading=\\\"lazy\\\"><br>\\n全部代码:</p>\",\"autoDesc\":true}")
export { comp, data }

if (import.meta.webpackHot) {
  import.meta.webpackHot.accept()
  if (__VUE_HMR_RUNTIME__.updatePageData) {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  }
}

if (import.meta.hot) {
  import.meta.hot.accept(({ data }) => {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  })
}
