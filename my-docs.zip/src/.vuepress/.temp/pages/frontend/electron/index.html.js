import comp from "D:/vue-theme-hope/my-docs/src/.vuepress/.temp/pages/frontend/electron/index.html.vue"
const data = JSON.parse("{\"path\":\"/frontend/electron/\",\"title\":\"Electron 教程\",\"lang\":\"zh-CN\",\"frontmatter\":{\"title\":\"Electron 教程\",\"icon\":\"electron\",\"index\":true,\"description\":\"Electron 桌面应用开发教程 Electron 是一个使用 JavaScript、HTML 和 CSS 构建桌面应用程序的框架。嵌入 Chromium 和 Node.js 到二进制的 Electron 允许您保持一个 JavaScript 代码代码库并创建在 Windows、macOS 和 Linux 上运行的跨平台应用——不需要本地开发经验。 ...\"},\"readingTime\":{\"minutes\":1.59,\"words\":476},\"filePathRelative\":\"frontend/electron/README.md\",\"excerpt\":\"\\n<p><strong>Electron</strong> 是一个使用 <strong>JavaScript</strong>、<strong>HTML</strong> 和 <strong>CSS</strong> 构建桌面应用程序的框架。嵌入 <strong>Chromium</strong> 和 <strong>Node.js</strong> 到二进制的 <strong>Electron</strong> 允许您保持一个 <strong>JavaScript</strong> 代码代码库并创建在 <strong>Windows</strong>、<strong>macOS</strong> 和 <strong>Linux</strong> 上运行的跨平台应用——不需要本地开发经验。</p>\",\"autoDesc\":true}")
export { comp, data }

if (import.meta.webpackHot) {
  import.meta.webpackHot.accept()
  if (__VUE_HMR_RUNTIME__.updatePageData) {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  }
}

if (import.meta.hot) {
  import.meta.hot.accept(({ data }) => {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  })
}
