<template><div><h1 id="_15-保存对话框" tabindex="-1"><a class="header-anchor" href="#_15-保存对话框"><span>15. 保存对话框</span></a></h1>
<p>保存对话框和选择文件对话框大致相同,选择文件对话框使用的是<code v-pre>showOpenDialog</code>方法,保存对话框使用的是<code v-pre>showSaveDialog</code>方法</p>
<p>首先定义一个保存文件的按钮</p>
<div class="language-html line-numbers-mode" data-highlighter="shiki" data-ext="html" style="--shiki-light:#383A42;--shiki-dark:#abb2bf;--shiki-light-bg:#FAFAFA;--shiki-dark-bg:#282c34"><pre class="shiki shiki-themes one-light one-dark-pro vp-code" v-pre=""><code class="language-html"><span class="line"></span>
<span class="line"><span style="--shiki-light:#383A42;--shiki-dark:#ABB2BF">&#x3C;</span><span style="--shiki-light:#E45649;--shiki-dark:#E06C75">button</span><span style="--shiki-light:#986801;--shiki-dark:#D19A66"> id</span><span style="--shiki-light:#383A42;--shiki-dark:#ABB2BF">=</span><span style="--shiki-light:#50A14F;--shiki-dark:#98C379">"savebtn"</span><span style="--shiki-light:#383A42;--shiki-dark:#ABB2BF">>保存文件&#x3C;/</span><span style="--shiki-light:#E45649;--shiki-dark:#E06C75">button</span><span style="--shiki-light:#383A42;--shiki-dark:#ABB2BF">></span></span>
<span class="line"></span>
<span class="line"><span style="--shiki-light:#383A42;--shiki-dark:#ABB2BF">在按钮点击事件中调用保存对话框,还是引入了`remote`模块,然后调用`showSaveDialog`方法 并且引入`fs`模块,用来创建文件</span></span>
<span class="line"></span>
<span class="line"><span style="--shiki-light:#383A42;--shiki-dark:#ABB2BF">```javascript</span></span>
<span class="line"><span style="--shiki-light:#383A42;--shiki-dark:#ABB2BF">const { dialog } = require("@electron/remote");</span></span>
<span class="line"><span style="--shiki-light:#383A42;--shiki-dark:#ABB2BF">const savebtn = document.getElementById("savebtn");</span></span>
<span class="line"><span style="--shiki-light:#383A42;--shiki-dark:#ABB2BF">savebtn.addEventListener("click", () => {</span></span>
<span class="line"><span style="--shiki-light:#383A42;--shiki-dark:#ABB2BF">    dialog.showSaveDialog({</span></span>
<span class="line"><span style="--shiki-light:#383A42;--shiki-dark:#ABB2BF">        title: "保存文件",</span></span>
<span class="line"><span style="--shiki-light:#383A42;--shiki-dark:#ABB2BF">        defaultPath: "保存一个文件",</span></span>
<span class="line"><span style="--shiki-light:#383A42;--shiki-dark:#ABB2BF">    }).then((res) => {</span></span>
<span class="line"><span style="--shiki-light:#383A42;--shiki-dark:#ABB2BF">        console.log(res); // 打印出来的是一个对象, filePath 中存放的是文件路径</span></span>
<span class="line"><span style="--shiki-light:#383A42;--shiki-dark:#ABB2BF">        fs.writeFileSync(res.filePath, "AirL.com"); // 我们使用同步方法创建文件</span></span>
<span class="line"><span style="--shiki-light:#383A42;--shiki-dark:#ABB2BF">    }).catch((err) => {</span></span>
<span class="line"><span style="--shiki-light:#383A42;--shiki-dark:#ABB2BF">        console.log(err); // 捕获异常</span></span>
<span class="line"><span style="--shiki-light:#383A42;--shiki-dark:#ABB2BF">    });</span></span>
<span class="line"><span style="--shiki-light:#383A42;--shiki-dark:#ABB2BF">    ;</span></span>
<span class="line"><span style="--shiki-light:#383A42;--shiki-dark:#ABB2BF">});</span></span></code></pre>
<div class="line-numbers" aria-hidden="true" style="counter-reset:line-number 0"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><figure><img src="/Electron/保存文件.jpg" alt="" tabindex="0" loading="lazy"><figcaption></figcaption></figure>
</div></template>


