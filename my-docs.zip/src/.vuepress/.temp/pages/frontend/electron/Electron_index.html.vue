<template><div><h1 id="electron介绍" tabindex="-1"><a class="header-anchor" href="#electron介绍"><span>Electron介绍</span></a></h1>
<h3 id="electron介绍是什么" tabindex="-1"><a class="header-anchor" href="#electron介绍是什么"><span>Electron介绍是什么?</span></a></h3>
<p><em><strong>Electron</strong></em>是一个使用<strong>JavaScript</strong>、<strong>HTML</strong>和<strong>CSS</strong>构建桌面应用程序的框架。 嵌入<strong>Chromium</strong>和<strong>Node.js</strong>到 二进制的<strong>Electron</strong>允许您保持一个<strong>JavaScript</strong>代码代码库并创建 在<strong>Windows</strong>上运行的跨平台应用<strong>macOS</strong>和<strong>Linux</strong>——不需要本地开发经验。</p>
</div></template>


