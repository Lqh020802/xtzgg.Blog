<template><div><h1 id="_19-剪切板" tabindex="-1"><a class="header-anchor" href="#_19-剪切板"><span>19. 剪切板</span></a></h1>
<p>剪切板功能使用的是 Electron 中的 clipboard 模块，该对象可以在应用程序中使用。</p>
<p>案例</p>
<p>引入 clipboard 模块：</p>
<div class="language-javascript line-numbers-mode" data-highlighter="shiki" data-ext="javascript" style="--shiki-light:#383A42;--shiki-dark:#abb2bf;--shiki-light-bg:#FAFAFA;--shiki-dark-bg:#282c34"><pre class="shiki shiki-themes one-light one-dark-pro vp-code" v-pre=""><code class="language-javascript"><span class="line"><span style="--shiki-light:#A626A4;--shiki-dark:#C678DD">  const</span><span style="--shiki-light:#383A42;--shiki-dark:#ABB2BF"> { </span><span style="--shiki-light:#986801;--shiki-dark:#E5C07B">clipboard</span><span style="--shiki-light:#383A42;--shiki-dark:#ABB2BF"> } </span><span style="--shiki-light:#0184BC;--shiki-dark:#56B6C2">=</span><span style="--shiki-light:#4078F2;--shiki-dark:#61AFEF"> require</span><span style="--shiki-light:#383A42;--shiki-dark:#ABB2BF">(</span><span style="--shiki-light:#50A14F;--shiki-dark:#98C379">"electron"</span><span style="--shiki-light:#383A42;--shiki-dark:#ABB2BF">); </span><span style="--shiki-light:#A0A1A7;--shiki-light-font-style:italic;--shiki-dark:#7F848E;--shiki-dark-font-style:italic">// 引入剪切板模块</span></span>
<span class="line"></span>
<span class="line"></span>
<span class="line"><span style="--shiki-light:#383A42;--shiki-dark:#E06C75">业务逻辑</span></span>
<span class="line"></span>
<span class="line"><span style="--shiki-light:#50A14F;--shiki-dark:#98C379">```javascript</span></span>
<span class="line"><span style="--shiki-light:#50A14F;--shiki-dark:#98C379"> btn1.addEventListener("click", () => {</span></span>
<span class="line"><span style="--shiki-light:#50A14F;--shiki-dark:#98C379">    clipboard.writeText(code.innerText); // 写入剪切板</span></span>
<span class="line"><span style="--shiki-light:#50A14F;--shiki-dark:#98C379">    alert("复制成功");</span></span>
<span class="line"><span style="--shiki-light:#50A14F;--shiki-dark:#98C379">});</span></span></code></pre>
<div class="line-numbers" aria-hidden="true" style="counter-reset:line-number 0"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><figure><img src="/Electron/剪切板.jpg" alt="" tabindex="0" loading="lazy"><figcaption></figcaption></figure>
</div></template>


