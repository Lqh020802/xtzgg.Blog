import comp from "D:/vue-theme-hope/my-docs/src/.vuepress/.temp/pages/frontend/electron/18-注册全局快捷键.html.vue"
const data = JSON.parse("{\"path\":\"/frontend/electron/18-%E6%B3%A8%E5%86%8C%E5%85%A8%E5%B1%80%E5%BF%AB%E6%8D%B7%E9%94%AE.html\",\"title\":\"18. 注册全局快捷键\",\"lang\":\"zh-CN\",\"frontmatter\":{\"title\":\"18. 注册全局快捷键\",\"icon\":\"simple-icons:electron\",\"description\":\"18. 注册全局快捷键 注册全局快捷键需要在 main.js 主线程中定义 使用的是globalShortcut这个模块 首先引入 globalShortcut 注意 使用 globalShortcut 注册全局快捷键时,必须在 ready 事件中注册,否则无法生效 注销全局快捷键, 在退出后,需要注销注册的全局快捷键,不然有可能会影响其他的应用\"},\"readingTime\":{\"minutes\":1.13,\"words\":339},\"filePathRelative\":\"frontend/electron/18-注册全局快捷键.md\",\"excerpt\":\"\\n<p>注册全局快捷键需要在 main.js 主线程中定义 使用的是<code>globalShortcut</code>这个模块</p>\\n<p>首先引入 globalShortcut</p>\\n<div class=\\\"language- line-numbers-mode\\\" data-highlighter=\\\"shiki\\\" data-ext=\\\"\\\" style=\\\"--shiki-light:#383A42;--shiki-dark:#abb2bf;--shiki-light-bg:#FAFAFA;--shiki-dark-bg:#282c34\\\"><pre class=\\\"shiki shiki-themes one-light one-dark-pro vp-code\\\"><code class=\\\"language-\\\"><span class=\\\"line\\\"><span></span></span>\\n<span class=\\\"line\\\"><span>```javascript</span></span>\\n<span class=\\\"line\\\"><span>const { app, BrowserWindow, BrowserView, globalShortcut } = require('electron')</span></span>\\n<span class=\\\"line\\\"><span></span></span>\\n<span class=\\\"line\\\"><span>引入完成后,我们来使用 globalShortcut 绑定全局快捷键</span></span></code></pre>\\n<div class=\\\"line-numbers\\\" aria-hidden=\\\"true\\\" style=\\\"counter-reset:line-number 0\\\"><div class=\\\"line-number\\\"></div><div class=\\\"line-number\\\"></div><div class=\\\"line-number\\\"></div><div class=\\\"line-number\\\"></div><div class=\\\"line-number\\\"></div></div></div>\",\"autoDesc\":true}")
export { comp, data }

if (import.meta.webpackHot) {
  import.meta.webpackHot.accept()
  if (__VUE_HMR_RUNTIME__.updatePageData) {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  }
}

if (import.meta.hot) {
  import.meta.hot.accept(({ data }) => {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  })
}
