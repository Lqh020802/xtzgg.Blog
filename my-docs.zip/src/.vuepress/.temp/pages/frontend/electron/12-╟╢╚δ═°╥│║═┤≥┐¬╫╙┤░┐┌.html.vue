<template><div><h1 id="_12-嵌入网页和打开子窗口" tabindex="-1"><a class="header-anchor" href="#_12-嵌入网页和打开子窗口"><span>12. 嵌入网页和打开子窗口</span></a></h1>
<p>提示</p>
<h2 id="嵌入网页" tabindex="-1"><a class="header-anchor" href="#嵌入网页"><span>嵌入网页</span></a></h2>
<p>在程序中嵌入网页需要使用到 BrowserView 模块</p>
<p>我们首先从<code v-pre>Election</code>中引入<code v-pre>BrowserView</code>模块, 因为 BrowserView 是运行在主线程中的,直接在<code v-pre>main.js</code>中引入即可.</p>
<div class="language-javascript line-numbers-mode" data-highlighter="shiki" data-ext="javascript" style="--shiki-light:#383A42;--shiki-dark:#abb2bf;--shiki-light-bg:#FAFAFA;--shiki-dark-bg:#282c34"><pre class="shiki shiki-themes one-light one-dark-pro vp-code" v-pre=""><code class="language-javascript"><span class="line"><span style="--shiki-light:#A626A4;--shiki-dark:#C678DD">const</span><span style="--shiki-light:#383A42;--shiki-dark:#ABB2BF"> { </span><span style="--shiki-light:#986801;--shiki-dark:#E5C07B">app</span><span style="--shiki-light:#383A42;--shiki-dark:#ABB2BF">, </span><span style="--shiki-light:#986801;--shiki-dark:#E5C07B">BrowserWindow</span><span style="--shiki-light:#383A42;--shiki-dark:#ABB2BF">, </span><span style="--shiki-light:#986801;--shiki-dark:#E5C07B">BrowserView</span><span style="--shiki-light:#383A42;--shiki-dark:#ABB2BF"> } </span><span style="--shiki-light:#0184BC;--shiki-dark:#56B6C2">=</span><span style="--shiki-light:#4078F2;--shiki-dark:#61AFEF"> require</span><span style="--shiki-light:#383A42;--shiki-dark:#ABB2BF">(</span><span style="--shiki-light:#50A14F;--shiki-dark:#98C379">"electron"</span><span style="--shiki-light:#383A42;--shiki-dark:#ABB2BF">);</span></span>
<span class="line"></span>
<span class="line"><span style="--shiki-light:#0184BC;--shiki-dark:#56B6C2">-</span><span style="--shiki-light:#383A42;--shiki-dark:#E06C75"> 创建</span><span style="--shiki-light:#383A42;--shiki-dark:#E06C75"> BrowserView</span><span style="--shiki-light:#383A42;--shiki-dark:#E06C75"> 实例</span><span style="--shiki-light:#383A42;--shiki-dark:#ABB2BF">,</span><span style="--shiki-light:#383A42;--shiki-dark:#E06C75">并且配置</span><span style="--shiki-light:#383A42;--shiki-dark:#E06C75"> BrowserView</span><span style="--shiki-light:#383A42;--shiki-dark:#E06C75"> 窗口大小</span></span>
<span class="line"></span>
<span class="line"></span>
<span class="line"><span style="--shiki-light:#50A14F;--shiki-dark:#98C379">```javascript</span></span>
<span class="line"><span style="--shiki-light:#50A14F;--shiki-dark:#98C379">let view = new BrowserView();</span></span>
<span class="line"><span style="--shiki-light:#50A14F;--shiki-dark:#98C379">mainWindow.setBrowserView(view);</span></span>
<span class="line"><span style="--shiki-light:#50A14F;--shiki-dark:#98C379">view.setBounds({ x: 0, y: 120, width: 1000, height: 680 });</span></span>
<span class="line"></span>
<span class="line"><span style="--shiki-light:#50A14F;--shiki-dark:#98C379">- 使用`</span><span style="--shiki-light:#4078F2;--shiki-dark:#61AFEF">BrowserView</span><span style="--shiki-light:#50A14F;--shiki-dark:#98C379">`实例的方法,将我们的网页引入</span></span>
<span class="line"></span>
<span class="line"></span>
<span class="line"><span style="--shiki-light:#50A14F;--shiki-dark:#98C379">```</span><span style="--shiki-light:#383A42;--shiki-dark:#E06C75">javascript</span></span>
<span class="line"><span style="--shiki-light:#383A42;--shiki-dark:#E5C07B">view</span><span style="--shiki-light:#383A42;--shiki-dark:#ABB2BF">.</span><span style="--shiki-light:#E45649;--shiki-dark:#E5C07B">webContents</span><span style="--shiki-light:#383A42;--shiki-dark:#ABB2BF">.</span><span style="--shiki-light:#4078F2;--shiki-dark:#61AFEF">loadURL</span><span style="--shiki-light:#383A42;--shiki-dark:#ABB2BF">(</span><span style="--shiki-light:#50A14F;--shiki-dark:#98C379">"https://lqh020802.github.io/"</span><span style="--shiki-light:#383A42;--shiki-dark:#ABB2BF">);</span></span>
<span class="line"></span>
<span class="line"><span style="--shiki-light:#383A42;--shiki-dark:#E06C75">完整代码</span><span style="--shiki-light:#383A42;--shiki-dark:#ABB2BF">:</span></span>
<span class="line"></span>
<span class="line"><span style="--shiki-light:#50A14F;--shiki-dark:#98C379">```javascript</span></span>
<span class="line"><span style="--shiki-light:#50A14F;--shiki-dark:#98C379">// 主进程</span></span>
<span class="line"><span style="--shiki-light:#50A14F;--shiki-dark:#98C379">const { app, BrowserWindow, BrowserView } = require("electron");</span></span>
<span class="line"><span style="--shiki-light:#50A14F;--shiki-dark:#98C379">const createWindow = () => {</span></span>
<span class="line"><span style="--shiki-light:#50A14F;--shiki-dark:#98C379">  const mainWindow = new BrowserWindow({</span></span>
<span class="line"><span style="--shiki-light:#50A14F;--shiki-dark:#98C379">    width: 800, // 控制打开窗口的宽高</span></span>
<span class="line"><span style="--shiki-light:#50A14F;--shiki-dark:#98C379">    height: 600,</span></span>
<span class="line"><span style="--shiki-light:#50A14F;--shiki-dark:#98C379">    webPreferences: {</span></span>
<span class="line"><span style="--shiki-light:#50A14F;--shiki-dark:#98C379">      nodeIntegration: true, // 渲染进程支持node</span></span>
<span class="line"><span style="--shiki-light:#50A14F;--shiki-dark:#98C379">      contextIsolation: false, // 关闭上下文隔离 默认为true</span></span>
<span class="line"><span style="--shiki-light:#50A14F;--shiki-dark:#98C379">      // 开启remote</span></span>
<span class="line"><span style="--shiki-light:#50A14F;--shiki-dark:#98C379">      enableRemoteModule: true,</span></span>
<span class="line"><span style="--shiki-light:#50A14F;--shiki-dark:#98C379">    },</span></span>
<span class="line"><span style="--shiki-light:#50A14F;--shiki-dark:#98C379">  });</span></span>
<span class="line"><span style="--shiki-light:#50A14F;--shiki-dark:#98C379">  mainWindow.loadFile("index.html"); // 读取渲染进程</span></span>
<span class="line"><span style="--shiki-light:#50A14F;--shiki-dark:#98C379">  mainWindow.webContents.openDevTools();</span></span>
<span class="line"><span style="--shiki-light:#50A14F;--shiki-dark:#98C379">  require("./main/menu.js");</span></span>
<span class="line"><span style="--shiki-light:#50A14F;--shiki-dark:#98C379">  require("@electron/remote/main").enable(mainWindow.webContents);</span></span>
<span class="line"><span style="--shiki-light:#50A14F;--shiki-dark:#98C379">  require("@electron/remote/main").initialize(); // 初始化Remote模块</span></span>
<span class="line"></span>
<span class="line"><span style="--shiki-light:#50A14F;--shiki-dark:#98C379">  let view = new BrowserView();</span></span>
<span class="line"><span style="--shiki-light:#50A14F;--shiki-dark:#98C379">  mainWindow.setBrowserView(view);</span></span>
<span class="line"><span style="--shiki-light:#50A14F;--shiki-dark:#98C379">  view.setBounds({ x: 0, y: 120, width: 1000, height: 680 });</span></span>
<span class="line"><span style="--shiki-light:#50A14F;--shiki-dark:#98C379">  view.webContents.loadURL("https://lqh020802.github.io/");</span></span>
<span class="line"><span style="--shiki-light:#50A14F;--shiki-dark:#98C379">};</span></span>
<span class="line"></span>
<span class="line"><span style="--shiki-light:#50A14F;--shiki-dark:#98C379">app.whenReady().then(() => {</span></span>
<span class="line"><span style="--shiki-light:#50A14F;--shiki-dark:#98C379">  // Electron 初始化完成调用createWindow()</span></span>
<span class="line"><span style="--shiki-light:#50A14F;--shiki-dark:#98C379">  createWindow();</span></span>
<span class="line"><span style="--shiki-light:#50A14F;--shiki-dark:#98C379">});</span></span></code></pre>
<div class="line-numbers" aria-hidden="true" style="counter-reset:line-number 0"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><p>效果:</p>
<figure><img src="/Electron/引入网页.jpg" alt="" tabindex="0" loading="lazy"><figcaption></figcaption></figure>
<p>提示</p>
<p>打开子窗口</p>
<ul>
<li>打开子窗口需要使用到 window.open() 方法</li>
</ul>
<p>这个方法可以在渲染进程中直接进行使用,不需要从<code v-pre>Election</code>中引入</p>
<p>首先在<code v-pre>index.html</code>中 设置一个 button 按钮,用于打开我们的子窗口</p>
<div class="language-html line-numbers-mode" data-highlighter="shiki" data-ext="html" style="--shiki-light:#383A42;--shiki-dark:#abb2bf;--shiki-light-bg:#FAFAFA;--shiki-dark-bg:#282c34"><pre class="shiki shiki-themes one-light one-dark-pro vp-code" v-pre=""><code class="language-html"><span class="line"><span style="--shiki-light:#A0A1A7;--shiki-light-font-style:italic;--shiki-dark:#7F848E;--shiki-dark-font-style:italic">&#x3C;!-- 给个 ID 方便我们获取元素--></span></span>
<span class="line"><span style="--shiki-light:#383A42;--shiki-dark:#ABB2BF">&#x3C;</span><span style="--shiki-light:#E45649;--shiki-dark:#E06C75">button</span><span style="--shiki-light:#986801;--shiki-dark:#D19A66"> id</span><span style="--shiki-light:#383A42;--shiki-dark:#ABB2BF">=</span><span style="--shiki-light:#50A14F;--shiki-dark:#98C379">"btn"</span><span style="--shiki-light:#383A42;--shiki-dark:#ABB2BF">>打开子窗口&#x3C;/</span><span style="--shiki-light:#E45649;--shiki-dark:#E06C75">button</span><span style="--shiki-light:#383A42;--shiki-dark:#ABB2BF">></span></span>
<span class="line"></span>
<span class="line"><span style="--shiki-light:#383A42;--shiki-dark:#ABB2BF">- 在渲染进程中使用 window.open() 方法打开子窗口</span></span>
<span class="line"></span>
<span class="line"></span>
<span class="line"><span style="--shiki-light:#383A42;--shiki-dark:#ABB2BF">```javascript</span></span>
<span class="line"><span style="--shiki-light:#383A42;--shiki-dark:#ABB2BF">const btn = document.getElementById("btn");</span></span>
<span class="line"><span style="--shiki-light:#383A42;--shiki-dark:#ABB2BF">btn.onclick = () => {</span></span>
<span class="line"><span style="--shiki-light:#383A42;--shiki-dark:#ABB2BF">  window.open("https://lqh020802.github.io/");</span></span>
<span class="line"><span style="--shiki-light:#383A42;--shiki-dark:#ABB2BF">};</span></span></code></pre>
<div class="line-numbers" aria-hidden="true" style="counter-reset:line-number 0"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><figure><img src="/Electron/子窗口.jpg" alt="" tabindex="0" loading="lazy"><figcaption></figcaption></figure>
</div></template>


