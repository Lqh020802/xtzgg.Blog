<template><div><h1 id="_06-运行流程" tabindex="-1"><a class="header-anchor" href="#_06-运行流程"><span>06. 运行流程</span></a></h1>
<figure><img src="/Electron/运行流程.jpg" alt="" tabindex="0" loading="lazy"><figcaption></figcaption></figure>
<ul>
<li>读取<code v-pre>package.json</code>中的入口文件,一般为<code v-pre>main.js</code></li>
</ul>
<figure><img src="/Electron/运行流程01.jpg" alt="" tabindex="0" loading="lazy"><figcaption></figcaption></figure>
<ul>
<li><strong>main.js</strong>主进程中创建渲染进程</li>
</ul>
<figure><img src="/Electron/运行流程02.jpg" alt="" tabindex="0" loading="lazy"><figcaption></figcaption></figure>
<ul>
<li>读取应用页面的布局和样式</li>
<li>使用IPC在主进程执行任务并获取信息</li>
</ul>
</div></template>


