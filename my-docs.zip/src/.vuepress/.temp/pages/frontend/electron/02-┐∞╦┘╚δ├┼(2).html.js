import comp from "D:/vue-theme-hope/my-docs/src/.vuepress/.temp/pages/frontend/electron/02-快速入门(2).html.vue"
const data = JSON.parse("{\"path\":\"/frontend/electron/02-%E5%BF%AB%E9%80%9F%E5%85%A5%E9%97%A8(2).html\",\"title\":\"02. 快速入门(2)\",\"lang\":\"zh-CN\",\"frontmatter\":{\"title\":\"02. 快速入门(2)\",\"icon\":\"simple-icons:electron\",\"description\":\"02. 快速入门(2) 提示 虽然你现在可以打开一个浏览器窗口，但你还需要一些额外的模板代码使其看起来更像是各平台原生的。 应用程序窗口在每个OS下有不同的行为，Electron将在app中实现这些约定的责任交给开发者们。 一般而言，你可以使用进程全局的platform属性来专门为某些操作系统运行代码。 关闭所有窗口时退出应用 (Windows & L...\"},\"readingTime\":{\"minutes\":2.92,\"words\":876},\"filePathRelative\":\"frontend/electron/02-快速入门(2).md\",\"excerpt\":\"\\n<div class=\\\"hint-container tip\\\">\\n<p class=\\\"hint-container-title\\\">提示</p>\\n<p>虽然你现在可以打开一个浏览器窗口，但你还需要一些额外的模板代码使其看起来更像是各平台原生的。 应用程序窗口在每个OS下有不同的行为，<code>Electron</code>将在<code>app</code>中实现这些约定的责任交给开发者们。 一般而言，你可以使用<code>进程</code>全局的<code>platform</code>属性来专门为某些操作系统运行代码。</p>\\n</div>\\n<h3>关闭所有窗口时退出应用 (Windows &amp; Linux)</h3>\",\"autoDesc\":true}")
export { comp, data }

if (import.meta.webpackHot) {
  import.meta.webpackHot.accept()
  if (__VUE_HMR_RUNTIME__.updatePageData) {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  }
}

if (import.meta.hot) {
  import.meta.hot.accept(({ data }) => {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  })
}
