import comp from "D:/vue-theme-hope/my-docs/src/.vuepress/.temp/pages/frontend/electron/05-进程间通讯.html.vue"
const data = JSON.parse("{\"path\":\"/frontend/electron/05-%E8%BF%9B%E7%A8%8B%E9%97%B4%E9%80%9A%E8%AE%AF.html\",\"title\":\"05. 进程间通讯\",\"lang\":\"zh-CN\",\"frontmatter\":{\"title\":\"05. 进程间通讯\",\"icon\":\"simple-icons:electron\",\"description\":\"05. 进程间通讯 提示 进程间通信 (IPC) 是在Electron中构建功能丰富的桌面应用程序的关键部分之一。 由于主进程和渲器进程在Electron的进程模型具有不同的职责，因此 IPC 是执行许多常见任务的唯一方法，例如从 UI 调用原生API或从原生菜单触发Web内容的更改。 IPC 通道 在Electron中，进程使用ipcMain和ipc...\"},\"readingTime\":{\"minutes\":3.93,\"words\":1179},\"filePathRelative\":\"frontend/electron/05-进程间通讯.md\",\"excerpt\":\"\\n<p>提示</p>\\n<p>进程间通信 (IPC) 是在<code>Electron</code>中构建功能丰富的桌面应用程序的关键部分之一。 由于主进程和渲器进程在<code>Electron</code>的进程模型具有不同的职责，因此 IPC 是执行许多常见任务的唯一方法，例如从 UI 调用原生<code>API</code>或从原生菜单触发<code>Web</code>内容的更改。</p>\\n<h3>IPC 通道</h3>\\n<p>在<code>Electron</code>中，进程使用<code>ipcMain</code>和<code>ipcRenderer</code>模块，通过开发人员定义的“通道”传递消息来进行通信。 这些通道是 任意和 双向 的。</p>\",\"autoDesc\":true}")
export { comp, data }

if (import.meta.webpackHot) {
  import.meta.webpackHot.accept()
  if (__VUE_HMR_RUNTIME__.updatePageData) {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  }
}

if (import.meta.hot) {
  import.meta.hot.accept(({ data }) => {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  })
}
