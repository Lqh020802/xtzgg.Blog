import comp from "D:/vue-theme-hope/my-docs/src/.vuepress/.temp/pages/frontend/electron/04-上下文隔离.html.vue"
const data = JSON.parse("{\"path\":\"/frontend/electron/04-%E4%B8%8A%E4%B8%8B%E6%96%87%E9%9A%94%E7%A6%BB.html\",\"title\":\"04. 上下文隔离\",\"lang\":\"zh-CN\",\"frontmatter\":{\"title\":\"04. 上下文隔离\",\"icon\":\"simple-icons:electron\",\"description\":\"04. 上下文隔离 上下文隔离是什么？ 上下文隔离功能将确保预加载脚本和Electron的内部逻辑 运行在所加载的webcontent网页 之外的另一个独立的上下文环境里。 这对安全性很重要，因为它有助于阻止网站访问Electron的内部组件 和预加载脚本可访问的高等级权限的API 。 这意味着，预加载脚本访问的window对象并不是网站所能访问的对象...\"},\"readingTime\":{\"minutes\":0.72,\"words\":217},\"filePathRelative\":\"frontend/electron/04-上下文隔离.md\",\"excerpt\":\"\\n<h3>上下文隔离是什么？</h3>\\n<p>上下文隔离功能将确保<code>预加载脚本</code>和<code>Electron</code>的内部逻辑 运行在所加载的<code>webcontent</code>网页 之外的另一个独立的上下文环境里。 这对安全性很重要，因为它有助于阻止网站访问<code>Electron</code>的内部组件 和<code>预加载脚本</code>可访问的高等级权限的API 。</p>\\n<p>这意味着，<code>预加载脚本</code>访问的<code>window</code>对象并不是网站所能访问的对象。</p>\\n<p>例如，在预加载脚本中设置<code>window.hello = 'wave'</code>并且启用了上下文隔离，当网站尝试访问<code>window.hello</code>对象时将返回<code>undefined</code>。</p>\",\"autoDesc\":true}")
export { comp, data }

if (import.meta.webpackHot) {
  import.meta.webpackHot.accept()
  if (__VUE_HMR_RUNTIME__.updatePageData) {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  }
}

if (import.meta.hot) {
  import.meta.hot.accept(({ data }) => {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  })
}
