<template><div><h1 id="_13-子窗口向父窗口传递信息" tabindex="-1"><a class="header-anchor" href="#_13-子窗口向父窗口传递信息"><span>13. 子窗口向父窗口传递信息</span></a></h1>
<ul>
<li></li>
</ul>
<p>既然是子窗口向父窗口传递信息,那么我们就必须需要一个主窗口和子窗口</p>
<p>首先,我们创建一个主窗口和一个子窗口,分别在主窗口和子窗口添加一个点击按钮</p>
<p>主窗口按钮用于打开子窗口</p>
<h2 id="子窗口按钮用于向主窗口发送信息" tabindex="-1"><a class="header-anchor" href="#子窗口按钮用于向主窗口发送信息"><span>子窗口按钮用于向主窗口发送信息</span></a></h2>
<p>子窗口中使用 window.opener.postMessage() 方法向主窗口发送信息</p>
<div class="language-javascript line-numbers-mode" data-highlighter="shiki" data-ext="javascript" style="--shiki-light:#383A42;--shiki-dark:#abb2bf;--shiki-light-bg:#FAFAFA;--shiki-dark-bg:#282c34"><pre class="shiki shiki-themes one-light one-dark-pro vp-code" v-pre=""><code class="language-javascript"><span class="line"><span style="--shiki-light:#A626A4;--shiki-dark:#C678DD">const</span><span style="--shiki-light:#986801;--shiki-dark:#E5C07B"> popbtn</span><span style="--shiki-light:#0184BC;--shiki-dark:#56B6C2"> =</span><span style="--shiki-light:#383A42;--shiki-dark:#E5C07B"> document</span><span style="--shiki-light:#383A42;--shiki-dark:#ABB2BF">.</span><span style="--shiki-light:#4078F2;--shiki-dark:#61AFEF">getElementById</span><span style="--shiki-light:#383A42;--shiki-dark:#ABB2BF">(</span><span style="--shiki-light:#50A14F;--shiki-dark:#98C379">"popbtn"</span><span style="--shiki-light:#383A42;--shiki-dark:#ABB2BF">);</span></span>
<span class="line"><span style="--shiki-light:#383A42;--shiki-dark:#E5C07B">popbtn</span><span style="--shiki-light:#383A42;--shiki-dark:#ABB2BF">.</span><span style="--shiki-light:#4078F2;--shiki-dark:#61AFEF">onclick</span><span style="--shiki-light:#0184BC;--shiki-dark:#56B6C2"> =</span><span style="--shiki-light:#A626A4;--shiki-dark:#C678DD"> function</span><span style="--shiki-light:#383A42;--shiki-dark:#ABB2BF"> () {</span></span>
<span class="line"><span style="--shiki-light:#383A42;--shiki-dark:#E5C07B">  window</span><span style="--shiki-light:#383A42;--shiki-dark:#ABB2BF">.</span><span style="--shiki-light:#E45649;--shiki-dark:#E5C07B">opener</span><span style="--shiki-light:#383A42;--shiki-dark:#ABB2BF">.</span><span style="--shiki-light:#4078F2;--shiki-dark:#61AFEF">postMessage</span><span style="--shiki-light:#383A42;--shiki-dark:#ABB2BF">(</span><span style="--shiki-light:#50A14F;--shiki-dark:#98C379">"我是子窗口,向父窗口传递信息"</span><span style="--shiki-light:#383A42;--shiki-dark:#ABB2BF">);</span></span>
<span class="line"><span style="--shiki-light:#383A42;--shiki-dark:#ABB2BF">};</span></span>
<span class="line"></span>
<span class="line"><span style="--shiki-light:#0184BC;--shiki-dark:#56B6C2">-</span><span style="--shiki-light:#383A42;--shiki-dark:#E06C75"> 主窗口打开子窗口</span><span style="--shiki-light:#383A42;--shiki-dark:#E06C75"> 并且接收子窗口传递过来的信息</span></span>
<span class="line"></span>
<span class="line"></span>
<span class="line"><span style="--shiki-light:#50A14F;--shiki-dark:#98C379">```javascript</span></span>
<span class="line"><span style="--shiki-light:#50A14F;--shiki-dark:#98C379">const btn = document.getElementById("btn");</span></span>
<span class="line"><span style="--shiki-light:#50A14F;--shiki-dark:#98C379">btn.onclick = () => {</span></span>
<span class="line"><span style="--shiki-light:#50A14F;--shiki-dark:#98C379">  window.open("../demo7/popup_page.html"); // 打开子窗口</span></span>
<span class="line"><span style="--shiki-light:#50A14F;--shiki-dark:#98C379">};</span></span>
<span class="line"><span style="--shiki-light:#50A14F;--shiki-dark:#98C379">window.addEventListener("message", (msg) => {</span></span>
<span class="line"><span style="--shiki-light:#50A14F;--shiki-dark:#98C379">  const mytext = document.getElementById("mytext"); // 接收子窗口传递的信息</span></span>
<span class="line"><span style="--shiki-light:#50A14F;--shiki-dark:#98C379">  mytext.innerHTML = msg.data;</span></span>
<span class="line"><span style="--shiki-light:#50A14F;--shiki-dark:#98C379">});</span></span></code></pre>
<div class="line-numbers" aria-hidden="true" style="counter-reset:line-number 0"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><figure><img src="/Electron/子窗口传递信息.jpg" alt="" tabindex="0" loading="lazy"><figcaption></figcaption></figure>
</div></template>


