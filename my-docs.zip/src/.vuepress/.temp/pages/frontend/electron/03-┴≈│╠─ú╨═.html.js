import comp from "D:/vue-theme-hope/my-docs/src/.vuepress/.temp/pages/frontend/electron/03-流程模型.html.vue"
const data = JSON.parse("{\"path\":\"/frontend/electron/03-%E6%B5%81%E7%A8%8B%E6%A8%A1%E5%9E%8B.html\",\"title\":\"03. 流程模型\",\"lang\":\"zh-CN\",\"frontmatter\":{\"title\":\"03. 流程模型\",\"icon\":\"simple-icons:electron\",\"description\":\"03. 流程模型 Electron 继承了来自 Chromium 的多进程架构，这使得此框架在架构上非常相似于一个现代的网页浏览器。 为什么不是一个单一的进程？ 网页浏览器是个极其复杂的应用程序。 除了显示网页内容的主要能力之外，他们还有许多次要的职责，例如：管理众多窗口 ( 或 标签页 ) 和加载第三方扩展。 在早期，浏览器通常使用单个进程来处理所有...\"},\"readingTime\":{\"minutes\":5.6,\"words\":1679},\"filePathRelative\":\"frontend/electron/03-流程模型.md\",\"excerpt\":\"\\n<p>Electron 继承了来自 Chromium 的多进程架构，这使得此框架在架构上非常相似于一个现代的网页浏览器。</p>\\n<h3>为什么不是一个单一的进程？</h3>\\n<p>网页浏览器是个极其复杂的应用程序。 除了显示网页内容的主要能力之外，他们还有许多次要的职责，例如：管理众多窗口 ( 或 标签页 ) 和加载第三方扩展。</p>\\n<p>在早期，浏览器通常使用单个进程来处理所有这些功能。 虽然这种模式意味着您打开每个标签页的开销较少，但也同时意味着一个网站的崩溃或无响应会影响到整个浏览器。</p>\\n<h3>多进程模型</h3>\\n<p>为了解决这个问题，<code>Chrome</code>团队决定让每个标签页在自己的进程中渲染， 从而限制了一个网页上的有误或恶意代码可能导致的对整个应用程序造成的伤害。 然后用单个浏览器进程控制这些标签页进程，以及整个应用程序的生命周期。下方来自<code>Chrome</code>漫画 的图表可视化了此模型</p>\",\"autoDesc\":true}")
export { comp, data }

if (import.meta.webpackHot) {
  import.meta.webpackHot.accept()
  if (__VUE_HMR_RUNTIME__.updatePageData) {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  }
}

if (import.meta.hot) {
  import.meta.hot.accept(({ data }) => {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  })
}
