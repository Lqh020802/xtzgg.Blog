import comp from "D:/vue-theme-hope/my-docs/src/.vuepress/.temp/pages/frontend/electron/16-断网提醒功能.html.vue"
const data = JSON.parse("{\"path\":\"/frontend/electron/16-%E6%96%AD%E7%BD%91%E6%8F%90%E9%86%92%E5%8A%9F%E8%83%BD.html\",\"title\":\"16. 断网提醒功能\",\"lang\":\"zh-CN\",\"frontmatter\":{\"title\":\"16. 断网提醒功能\",\"icon\":\"simple-icons:electron\",\"description\":\"16. 断网提醒功能 断网提醒功能很简单,使用的是 window 的onoffline和ononline事件. 用来提醒用户网络已经断开或者网络已经连接上 断网网络 网络连接\"},\"readingTime\":{\"minutes\":0.4,\"words\":121},\"filePathRelative\":\"frontend/electron/16-断网提醒功能.md\",\"excerpt\":\"\\n<p>断网提醒功能很简单,使用的是 window 的<code>onoffline</code>和<code>ononline</code>事件. 用来提醒用户网络已经断开或者网络已经连接上</p>\\n<div class=\\\"language-html line-numbers-mode\\\" data-highlighter=\\\"shiki\\\" data-ext=\\\"html\\\" style=\\\"--shiki-light:#383A42;--shiki-dark:#abb2bf;--shiki-light-bg:#FAFAFA;--shiki-dark-bg:#282c34\\\"><pre class=\\\"shiki shiki-themes one-light one-dark-pro vp-code\\\"><code class=\\\"language-html\\\"><span class=\\\"line\\\"><span style=\\\"--shiki-light:#383A42;--shiki-dark:#ABB2BF\\\"> &lt;</span><span style=\\\"--shiki-light:#E45649;--shiki-dark:#E06C75\\\">h2</span><span style=\\\"--shiki-light:#383A42;--shiki-dark:#ABB2BF\\\">&gt;断网提醒功能&lt;/</span><span style=\\\"--shiki-light:#E45649;--shiki-dark:#E06C75\\\">h2</span><span style=\\\"--shiki-light:#383A42;--shiki-dark:#ABB2BF\\\">&gt;</span></span>\\n<span class=\\\"line\\\"></span>\\n<span class=\\\"line\\\"><span style=\\\"--shiki-light:#383A42;--shiki-dark:#ABB2BF\\\">```javascript</span></span>\\n<span class=\\\"line\\\"><span style=\\\"--shiki-light:#383A42;--shiki-dark:#ABB2BF\\\"> window.addEventListener(\\\"online\\\", () =&gt; {</span></span>\\n<span class=\\\"line\\\"><span style=\\\"--shiki-light:#383A42;--shiki-dark:#ABB2BF\\\">    alert(\\\"网络连接成功\\\");</span></span>\\n<span class=\\\"line\\\"><span style=\\\"--shiki-light:#383A42;--shiki-dark:#ABB2BF\\\">});</span></span>\\n<span class=\\\"line\\\"><span style=\\\"--shiki-light:#383A42;--shiki-dark:#ABB2BF\\\">window.addEventListener(\\\"offline\\\", () =&gt; {</span></span>\\n<span class=\\\"line\\\"><span style=\\\"--shiki-light:#383A42;--shiki-dark:#ABB2BF\\\">    alert(\\\"断网了,您的网络连接有问题哦,请检查网络\\\");</span></span>\\n<span class=\\\"line\\\"><span style=\\\"--shiki-light:#383A42;--shiki-dark:#ABB2BF\\\">});</span></span></code></pre>\\n<div class=\\\"line-numbers\\\" aria-hidden=\\\"true\\\" style=\\\"counter-reset:line-number 0\\\"><div class=\\\"line-number\\\"></div><div class=\\\"line-number\\\"></div><div class=\\\"line-number\\\"></div><div class=\\\"line-number\\\"></div><div class=\\\"line-number\\\"></div><div class=\\\"line-number\\\"></div><div class=\\\"line-number\\\"></div><div class=\\\"line-number\\\"></div><div class=\\\"line-number\\\"></div></div></div>\",\"autoDesc\":true}")
export { comp, data }

if (import.meta.webpackHot) {
  import.meta.webpackHot.accept()
  if (__VUE_HMR_RUNTIME__.updatePageData) {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  }
}

if (import.meta.hot) {
  import.meta.hot.accept(({ data }) => {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  })
}
