<template><div><h1 id="electron-桌面应用开发教程" tabindex="-1"><a class="header-anchor" href="#electron-桌面应用开发教程"><span>Electron 桌面应用开发教程</span></a></h1>
<p><strong>Electron</strong> 是一个使用 <strong>JavaScript</strong>、<strong>HTML</strong> 和 <strong>CSS</strong> 构建桌面应用程序的框架。嵌入 <strong>Chromium</strong> 和 <strong>Node.js</strong> 到二进制的 <strong>Electron</strong> 允许您保持一个 <strong>JavaScript</strong> 代码代码库并创建在 <strong>Windows</strong>、<strong>macOS</strong> 和 <strong>Linux</strong> 上运行的跨平台应用——不需要本地开发经验。</p>
<h2 id="📚-教程目录" tabindex="-1"><a class="header-anchor" href="#📚-教程目录"><span>📚 教程目录</span></a></h2>
<h3 id="基础入门" tabindex="-1"><a class="header-anchor" href="#基础入门"><span>基础入门</span></a></h3>
<ul>
<li><RouteLink to="/frontend/electron/Electron_index.html">Electron 介绍</RouteLink></li>
<li><RouteLink to="/frontend/electron/01-%E5%BF%AB%E9%80%9F%E5%85%A5%E9%97%A8.html">01-快速入门</RouteLink></li>
<li><RouteLink to="/frontend/electron/02-%E5%BF%AB%E9%80%9F%E5%85%A5%E9%97%A8(2).html">02-快速入门(2)</RouteLink></li>
<li><RouteLink to="/frontend/electron/03-%E6%B5%81%E7%A8%8B%E6%A8%A1%E5%9E%8B.html">03-流程模型</RouteLink></li>
<li><RouteLink to="/frontend/electron/04-%E4%B8%8A%E4%B8%8B%E6%96%87%E9%9A%94%E7%A6%BB.html">04-上下文隔离</RouteLink></li>
<li><RouteLink to="/frontend/electron/05-%E8%BF%9B%E7%A8%8B%E9%97%B4%E9%80%9A%E8%AE%AF.html">05-进程间通讯</RouteLink></li>
<li><RouteLink to="/frontend/electron/06-%E8%BF%90%E8%A1%8C%E6%B5%81%E7%A8%8B.html">06-运行流程</RouteLink></li>
<li><RouteLink to="/frontend/electron/07-%E4%B8%BB%E8%BF%9B%E7%A8%8B%E5%92%8C%E6%B8%B2%E6%9F%93%E8%BF%9B%E7%A8%8B.html">07-主进程和渲染进程</RouteLink></li>
<li><RouteLink to="/frontend/electron/08-Remote%E6%A8%A1%E5%9D%97.html">08-Remote 模块</RouteLink></li>
</ul>
<h3 id="功能实现" tabindex="-1"><a class="header-anchor" href="#功能实现"><span>功能实现</span></a></h3>
<ul>
<li><RouteLink to="/frontend/electron/09-%E8%8F%9C%E5%8D%95%E7%9A%84%E5%88%9B%E5%BB%BA%E5%92%8C%E5%9F%BA%E6%9C%AC%E4%BD%BF%E7%94%A8.html">09-菜单的创建和基本使用</RouteLink></li>
<li><RouteLink to="/frontend/electron/10-%E5%8F%B3%E9%94%AE%E8%8F%9C%E5%8D%95.html">10-右键菜单</RouteLink></li>
<li><RouteLink to="/frontend/electron/11-%E9%80%9A%E8%BF%87%E6%B5%8F%E8%A7%88%E5%99%A8%E6%89%93%E5%BC%80%E7%BD%91%E9%A1%B5.html">11-通过浏览器打开网页</RouteLink></li>
<li><RouteLink to="/frontend/electron/12-%E5%B5%8C%E5%85%A5%E7%BD%91%E9%A1%B5%E5%92%8C%E6%89%93%E5%BC%80%E5%AD%90%E7%AA%97%E5%8F%A3.html">12-嵌入网页和打开子窗口</RouteLink></li>
<li><RouteLink to="/frontend/electron/13-%E5%AD%90%E7%AA%97%E5%8F%A3%E5%90%91%E7%88%B6%E7%AA%97%E5%8F%A3%E4%BC%A0%E9%80%92%E4%BF%A1%E6%81%AF.html">13-子窗口向父窗口传递信息</RouteLink></li>
<li><RouteLink to="/frontend/electron/14-%E9%80%89%E6%8B%A9%E6%96%87%E4%BB%B6%E5%AF%B9%E8%AF%9D%E6%A1%86.html">14-选择文件对话框</RouteLink></li>
<li><RouteLink to="/frontend/electron/15-%E4%BF%9D%E5%AD%98%E5%AF%B9%E8%AF%9D%E6%A1%86.html">15-保存对话框</RouteLink></li>
<li><RouteLink to="/frontend/electron/16-%E6%96%AD%E7%BD%91%E6%8F%90%E9%86%92%E5%8A%9F%E8%83%BD.html">16-断网提醒功能</RouteLink></li>
<li><RouteLink to="/frontend/electron/17-%E5%BA%95%E9%83%A8%E6%B6%88%E6%81%AF%E9%80%9A%E7%9F%A5.html">17-底部消息通知</RouteLink></li>
<li><RouteLink to="/frontend/electron/18-%E6%B3%A8%E5%86%8C%E5%85%A8%E5%B1%80%E5%BF%AB%E6%8D%B7%E9%94%AE.html">18-注册全局快捷键</RouteLink></li>
<li><RouteLink to="/frontend/electron/19-%E5%89%AA%E5%88%87%E6%9D%BF.html">19-剪切板</RouteLink></li>
</ul>
<h2 id="🎯-学习路径" tabindex="-1"><a class="header-anchor" href="#🎯-学习路径"><span>🎯 学习路径</span></a></h2>
<ol>
<li>从 <strong>Electron 介绍</strong> 开始了解 Electron 的基本概念</li>
<li>按照 <strong>快速入门</strong> 系列搭建第一个应用</li>
<li>深入学习 <strong>流程模型</strong> 和 <strong>进程间通讯</strong></li>
<li>掌握各种功能实现，如菜单、窗口、对话框等</li>
</ol>
<h2 id="📖-相关资源" tabindex="-1"><a class="header-anchor" href="#📖-相关资源"><span>📖 相关资源</span></a></h2>
<ul>
<li><a href="https://www.electronjs.org/" target="_blank" rel="noopener noreferrer">Electron 官方文档</a></li>
<li><a href="https://github.com/electron/electron" target="_blank" rel="noopener noreferrer">Electron GitHub</a></li>
</ul>
</div></template>


