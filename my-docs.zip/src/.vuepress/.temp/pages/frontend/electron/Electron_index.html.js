import comp from "D:/vue-theme-hope/my-docs/src/.vuepress/.temp/pages/frontend/electron/Electron_index.html.vue"
const data = JSON.parse("{\"path\":\"/frontend/electron/Electron_index.html\",\"title\":\"Electron介绍\",\"lang\":\"zh-CN\",\"frontmatter\":{\"title\":\"Electron介绍\",\"icon\":\"simple-icons:electron\",\"description\":\"Electron介绍 Electron介绍是什么? Electron是一个使用JavaScript、HTML和CSS构建桌面应用程序的框架。 嵌入Chromium和Node.js到 二进制的Electron允许您保持一个JavaScript代码代码库并创建 在Windows上运行的跨平台应用macOS和Linux——不需要本地开发经验。\"},\"readingTime\":{\"minutes\":0.29,\"words\":88},\"filePathRelative\":\"frontend/electron/Electron_index.md\",\"excerpt\":\"\\n<h3>Electron介绍是什么?</h3>\\n<p><em><strong>Electron</strong></em>是一个使用<strong>JavaScript</strong>、<strong>HTML</strong>和<strong>CSS</strong>构建桌面应用程序的框架。 嵌入<strong>Chromium</strong>和<strong>Node.js</strong>到 二进制的<strong>Electron</strong>允许您保持一个<strong>JavaScript</strong>代码代码库并创建 在<strong>Windows</strong>上运行的跨平台应用<strong>macOS</strong>和<strong>Linux</strong>——不需要本地开发经验。</p>\",\"autoDesc\":true}")
export { comp, data }

if (import.meta.webpackHot) {
  import.meta.webpackHot.accept()
  if (__VUE_HMR_RUNTIME__.updatePageData) {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  }
}

if (import.meta.hot) {
  import.meta.hot.accept(({ data }) => {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  })
}
