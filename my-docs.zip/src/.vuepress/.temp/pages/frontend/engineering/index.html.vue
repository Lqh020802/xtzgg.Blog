<template><div><h1 id="前端工程化" tabindex="-1"><a class="header-anchor" href="#前端工程化"><span>前端工程化</span></a></h1>
<h3 id="包管理与私服" tabindex="-1"><a class="header-anchor" href="#包管理与私服"><span>包管理与私服</span></a></h3>
<ul>
<li><RouteLink to="/frontend/engineering/npm-registry.html">NPM 私服</RouteLink> - 搭建企业级私有 npm 仓库</li>
</ul>
<h2 id="构建工具" tabindex="-1"><a class="header-anchor" href="#构建工具"><span>构建工具</span></a></h2>
<h3 id="webpack" tabindex="-1"><a class="header-anchor" href="#webpack"><span>Webpack</span></a></h3>
<ul>
<li>核心概念</li>
<li>Loader 和 Plugin</li>
<li>代码分割</li>
<li>性能优化</li>
</ul>
<h3 id="vite" tabindex="-1"><a class="header-anchor" href="#vite"><span>Vite</span></a></h3>
<ul>
<li>快速冷启动</li>
<li>模块热更新</li>
<li>插件系统</li>
<li>生产构建</li>
</ul>
<h3 id="rollup" tabindex="-1"><a class="header-anchor" href="#rollup"><span>Rollup</span></a></h3>
<ul>
<li>模块打包</li>
<li>Tree-shaking</li>
<li>插件开发</li>
</ul>
<h2 id="包管理工具" tabindex="-1"><a class="header-anchor" href="#包管理工具"><span>包管理工具</span></a></h2>
<h3 id="npm-yarn-pnpm" tabindex="-1"><a class="header-anchor" href="#npm-yarn-pnpm"><span>npm/yarn/pnpm</span></a></h3>
<ul>
<li>依赖管理</li>
<li>版本控制</li>
<li>工作区 (Workspace)</li>
<li>脚本命令</li>
</ul>
<h2 id="代码质量" tabindex="-1"><a class="header-anchor" href="#代码质量"><span>代码质量</span></a></h2>
<h3 id="eslint" tabindex="-1"><a class="header-anchor" href="#eslint"><span>ESLint</span></a></h3>
<ul>
<li>代码规范</li>
<li>规则配置</li>
<li>自动修复</li>
</ul>
<h3 id="prettier" tabindex="-1"><a class="header-anchor" href="#prettier"><span>Prettier</span></a></h3>
<ul>
<li>代码格式化</li>
<li>配置选项</li>
</ul>
<h3 id="typescript" tabindex="-1"><a class="header-anchor" href="#typescript"><span>TypeScript</span></a></h3>
<ul>
<li>类型系统</li>
<li>接口定义</li>
<li>泛型使用</li>
</ul>
<h2 id="ci-cd" tabindex="-1"><a class="header-anchor" href="#ci-cd"><span>CI/CD</span></a></h2>
<h3 id="持续集成" tabindex="-1"><a class="header-anchor" href="#持续集成"><span>持续集成</span></a></h3>
<ul>
<li>GitHub Actions</li>
<li>GitLab CI</li>
<li>自动化测试</li>
</ul>
<h3 id="部署流程" tabindex="-1"><a class="header-anchor" href="#部署流程"><span>部署流程</span></a></h3>
<ul>
<li>构建优化</li>
<li>环境配置</li>
<li>发布策略</li>
</ul>
<hr>
<blockquote>
<p>持续更新中...</p>
</blockquote>
</div></template>


