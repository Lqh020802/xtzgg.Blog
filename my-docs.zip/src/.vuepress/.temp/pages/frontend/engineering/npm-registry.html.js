import comp from "D:/vue-theme-hope/my-docs/src/.vuepress/.temp/pages/frontend/engineering/npm-registry.html.vue"
const data = JSON.parse("{\"path\":\"/frontend/engineering/npm-registry.html\",\"title\":\"NPM 私服\",\"lang\":\"zh-CN\",\"frontmatter\":{\"title\":\"NPM 私服\",\"icon\":\"mdi:tools\",\"description\":\"NPM 私服 1. 什么是 NPM 私服 npm 私服（Private npm Registry） 是企业或团队内部搭建的私有 npm 仓库，用于存储、管理和分发内部开发的 npm 包，同时可以缓存公共 npm 仓库（如 npmjs.com）的包，兼具 \\\"私有包管理\\\" 和 \\\"公共包加速\\\" 的双重作用。 1.1 架构示意图 1.2 核心概念 私有仓库： ...\",\"head\":[[\"script\",{\"type\":\"application/ld+json\"},\"{\\\"@context\\\":\\\"https://schema.org\\\",\\\"@type\\\":\\\"Article\\\",\\\"headline\\\":\\\"NPM 私服\\\",\\\"image\\\":[\\\"\\\"],\\\"dateModified\\\":null,\\\"author\\\":[{\\\"@type\\\":\\\"Person\\\",\\\"name\\\":\\\"小兔子乖乖\\\",\\\"url\\\":\\\"https://mister-hope.com\\\"}]}\"],[\"meta\",{\"property\":\"og:url\",\"content\":\"https://mister-hope.github.io/xtzgg.Blog/frontend/engineering/npm-registry.html\"}],[\"meta\",{\"property\":\"og:site_name\",\"content\":\"小兔子乖乖\"}],[\"meta\",{\"property\":\"og:title\",\"content\":\"NPM 私服\"}],[\"meta\",{\"property\":\"og:description\",\"content\":\"NPM 私服 1. 什么是 NPM 私服 npm 私服（Private npm Registry） 是企业或团队内部搭建的私有 npm 仓库，用于存储、管理和分发内部开发的 npm 包，同时可以缓存公共 npm 仓库（如 npmjs.com）的包，兼具 \\\"私有包管理\\\" 和 \\\"公共包加速\\\" 的双重作用。 1.1 架构示意图 1.2 核心概念 私有仓库： ...\"}],[\"meta\",{\"property\":\"og:type\",\"content\":\"article\"}],[\"meta\",{\"property\":\"og:locale\",\"content\":\"zh-CN\"}]]},\"readingTime\":{\"minutes\":9.23,\"words\":2768},\"filePathRelative\":\"frontend/engineering/npm-registry.md\",\"excerpt\":\"\\n<h2>1. 什么是 NPM 私服</h2>\\n<p><strong>npm 私服（Private npm Registry）</strong> 是企业或团队内部搭建的私有 npm 仓库，用于存储、管理和分发内部开发的 npm 包，同时可以缓存公共 npm 仓库（如 <a href=\\\"http://npmjs.com\\\" target=\\\"_blank\\\" rel=\\\"noopener noreferrer\\\">npmjs.com</a>）的包，兼具 <strong>\\\"私有包管理\\\"</strong> 和 <strong>\\\"公共包加速\\\"</strong> 的双重作用。</p>\\n<h3>1.1 架构示意图</h3>\",\"autoDesc\":true}")
export { comp, data }

if (import.meta.webpackHot) {
  import.meta.webpackHot.accept()
  if (__VUE_HMR_RUNTIME__.updatePageData) {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  }
}

if (import.meta.hot) {
  import.meta.hot.accept(({ data }) => {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  })
}
