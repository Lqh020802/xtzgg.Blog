import comp from "D:/vue-theme-hope/my-docs/src/.vuepress/.temp/pages/frontend/engineering/index.html.vue"
const data = JSON.parse("{\"path\":\"/frontend/engineering/\",\"title\":\"前端工程化\",\"lang\":\"zh-CN\",\"frontmatter\":{\"title\":\"前端工程化\",\"icon\":\"mdi:tools\",\"description\":\"前端工程化 包管理与私服 - 搭建企业级私有 npm 仓库 构建工具 Webpack 核心概念 Loader 和 Plugin 代码分割 性能优化 Vite 快速冷启动 模块热更新 插件系统 生产构建 Rollup 模块打包 Tree-shaking 插件开发 包管理工具 npm/yarn/pnpm 依赖管理 版本控制 工作区 (Workspace) ...\",\"head\":[[\"script\",{\"type\":\"application/ld+json\"},\"{\\\"@context\\\":\\\"https://schema.org\\\",\\\"@type\\\":\\\"Article\\\",\\\"headline\\\":\\\"前端工程化\\\",\\\"image\\\":[\\\"\\\"],\\\"dateModified\\\":null,\\\"author\\\":[{\\\"@type\\\":\\\"Person\\\",\\\"name\\\":\\\"小兔子乖乖\\\",\\\"url\\\":\\\"https://mister-hope.com\\\"}]}\"],[\"meta\",{\"property\":\"og:url\",\"content\":\"https://mister-hope.github.io/xtzgg.Blog/frontend/engineering/\"}],[\"meta\",{\"property\":\"og:site_name\",\"content\":\"小兔子乖乖\"}],[\"meta\",{\"property\":\"og:title\",\"content\":\"前端工程化\"}],[\"meta\",{\"property\":\"og:description\",\"content\":\"前端工程化 包管理与私服 - 搭建企业级私有 npm 仓库 构建工具 Webpack 核心概念 Loader 和 Plugin 代码分割 性能优化 Vite 快速冷启动 模块热更新 插件系统 生产构建 Rollup 模块打包 Tree-shaking 插件开发 包管理工具 npm/yarn/pnpm 依赖管理 版本控制 工作区 (Workspace) ...\"}],[\"meta\",{\"property\":\"og:type\",\"content\":\"article\"}],[\"meta\",{\"property\":\"og:locale\",\"content\":\"zh-CN\"}]]},\"readingTime\":{\"minutes\":0.61,\"words\":183},\"filePathRelative\":\"frontend/engineering/README.md\",\"excerpt\":\"\\n<h3>包管理与私服</h3>\\n<ul>\\n<li><a href=\\\"/xtzgg.Blog/frontend/engineering/npm-registry.html\\\" target=\\\"_blank\\\">NPM 私服</a> - 搭建企业级私有 npm 仓库</li>\\n</ul>\\n<h2>构建工具</h2>\\n<h3>Webpack</h3>\\n<ul>\\n<li>核心概念</li>\\n<li>Loader 和 Plugin</li>\\n<li>代码分割</li>\\n<li>性能优化</li>\\n</ul>\\n<h3>Vite</h3>\\n<ul>\\n<li>快速冷启动</li>\\n<li>模块热更新</li>\\n<li>插件系统</li>\\n<li>生产构建</li>\\n</ul>\",\"autoDesc\":true}")
export { comp, data }

if (import.meta.webpackHot) {
  import.meta.webpackHot.accept()
  if (__VUE_HMR_RUNTIME__.updatePageData) {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  }
}

if (import.meta.hot) {
  import.meta.hot.accept(({ data }) => {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  })
}
