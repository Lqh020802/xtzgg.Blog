import comp from "D:/vue-theme-hope/my-docs/src/.vuepress/.temp/pages/frontend/javascript/debounce-throttle.html.vue"
const data = JSON.parse("{\"path\":\"/frontend/javascript/debounce-throttle.html\",\"title\":\"防抖和节流\",\"lang\":\"zh-CN\",\"frontmatter\":{\"title\":\"防抖和节流\",\"icon\":\"logos:javascript\",\"description\":\"防抖和节流 防抖（Debounce） 和 节流（Throttle） 是 JavaScript 中用于控制高频事件触发频率的两种优化技术，常用于处理 resize、scroll、input、click 等可能被频繁触发的事件，避免因事件密集执行导致的性能问题（如频繁 DOM 操作、接口请求）。 二者核心目标相同，但适用场景和实现逻辑不同。 1. 问题场景...\",\"head\":[[\"script\",{\"type\":\"application/ld+json\"},\"{\\\"@context\\\":\\\"https://schema.org\\\",\\\"@type\\\":\\\"Article\\\",\\\"headline\\\":\\\"防抖和节流\\\",\\\"image\\\":[\\\"\\\"],\\\"dateModified\\\":null,\\\"author\\\":[{\\\"@type\\\":\\\"Person\\\",\\\"name\\\":\\\"小兔子乖乖\\\",\\\"url\\\":\\\"https://mister-hope.com\\\"}]}\"],[\"meta\",{\"property\":\"og:url\",\"content\":\"https://mister-hope.github.io/xtzgg.Blog/frontend/javascript/debounce-throttle.html\"}],[\"meta\",{\"property\":\"og:site_name\",\"content\":\"小兔子乖乖\"}],[\"meta\",{\"property\":\"og:title\",\"content\":\"防抖和节流\"}],[\"meta\",{\"property\":\"og:description\",\"content\":\"防抖和节流 防抖（Debounce） 和 节流（Throttle） 是 JavaScript 中用于控制高频事件触发频率的两种优化技术，常用于处理 resize、scroll、input、click 等可能被频繁触发的事件，避免因事件密集执行导致的性能问题（如频繁 DOM 操作、接口请求）。 二者核心目标相同，但适用场景和实现逻辑不同。 1. 问题场景...\"}],[\"meta\",{\"property\":\"og:type\",\"content\":\"article\"}],[\"meta\",{\"property\":\"og:locale\",\"content\":\"zh-CN\"}]]},\"readingTime\":{\"minutes\":10.79,\"words\":3238},\"filePathRelative\":\"frontend/javascript/debounce-throttle.md\",\"excerpt\":\"\\n<p><strong>防抖（Debounce）</strong> 和 <strong>节流（Throttle）</strong> 是 JavaScript 中用于控制高频事件触发频率的两种优化技术，常用于处理 <code>resize</code>、<code>scroll</code>、<code>input</code>、<code>click</code> 等可能被频繁触发的事件，避免因事件密集执行导致的性能问题（如频繁 DOM 操作、接口请求）。</p>\\n<p><strong>二者核心目标相同，但适用场景和实现逻辑不同。</strong></p>\\n<h2>1. 问题场景</h2>\\n<h3>1.1 高频事件的性能问题</h3>\",\"autoDesc\":true}")
export { comp, data }

if (import.meta.webpackHot) {
  import.meta.webpackHot.accept()
  if (__VUE_HMR_RUNTIME__.updatePageData) {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  }
}

if (import.meta.hot) {
  import.meta.hot.accept(({ data }) => {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  })
}
