import comp from "D:/vue-theme-hope/my-docs/src/.vuepress/.temp/pages/frontend/javascript/array-methods.html.vue"
const data = JSON.parse("{\"path\":\"/frontend/javascript/array-methods.html\",\"title\":\"常见的数组方法\",\"lang\":\"zh-CN\",\"frontmatter\":{\"title\":\"常见的数组方法\",\"icon\":\"logos:javascript\",\"description\":\"常见的数组方法 JavaScript 数组的方法按是否修改原数组可分为： 可变方法（修改原数组） 不可变方法（返回新数组/值，不修改原数组） 1. 会改变原数组的方法 1.1 方法速览表 1.2 详细用法 push() - 末尾添加 pop() - 末尾删除 unshift() - 开头添加 shift() - 开头删除 splice() - 万能方法...\",\"head\":[[\"script\",{\"type\":\"application/ld+json\"},\"{\\\"@context\\\":\\\"https://schema.org\\\",\\\"@type\\\":\\\"Article\\\",\\\"headline\\\":\\\"常见的数组方法\\\",\\\"image\\\":[\\\"\\\"],\\\"dateModified\\\":null,\\\"author\\\":[{\\\"@type\\\":\\\"Person\\\",\\\"name\\\":\\\"小兔子乖乖\\\",\\\"url\\\":\\\"https://mister-hope.com\\\"}]}\"],[\"meta\",{\"property\":\"og:url\",\"content\":\"https://mister-hope.github.io/xtzgg.Blog/frontend/javascript/array-methods.html\"}],[\"meta\",{\"property\":\"og:site_name\",\"content\":\"小兔子乖乖\"}],[\"meta\",{\"property\":\"og:title\",\"content\":\"常见的数组方法\"}],[\"meta\",{\"property\":\"og:description\",\"content\":\"常见的数组方法 JavaScript 数组的方法按是否修改原数组可分为： 可变方法（修改原数组） 不可变方法（返回新数组/值，不修改原数组） 1. 会改变原数组的方法 1.1 方法速览表 1.2 详细用法 push() - 末尾添加 pop() - 末尾删除 unshift() - 开头添加 shift() - 开头删除 splice() - 万能方法...\"}],[\"meta\",{\"property\":\"og:type\",\"content\":\"article\"}],[\"meta\",{\"property\":\"og:locale\",\"content\":\"zh-CN\"}]]},\"readingTime\":{\"minutes\":10.94,\"words\":3281},\"filePathRelative\":\"frontend/javascript/array-methods.md\",\"excerpt\":\"\\n<p>JavaScript 数组的方法按<strong>是否修改原数组</strong>可分为：</p>\\n<ul>\\n<li><strong>可变方法</strong>（修改原数组）</li>\\n<li><strong>不可变方法</strong>（返回新数组/值，不修改原数组）</li>\\n</ul>\\n<h2>1. 会改变原数组的方法</h2>\\n<h3>1.1 方法速览表</h3>\\n<table>\\n<thead>\\n<tr>\\n<th>方法</th>\\n<th>功能描述</th>\\n<th>返回值</th>\\n</tr>\\n</thead>\\n<tbody>\\n<tr>\\n<td><code>push()</code></td>\\n<td>向数组末尾添加一个/多个元素</td>\\n<td>新长度</td>\\n</tr>\\n<tr>\\n<td><code>pop()</code></td>\\n<td>删除数组最后一个元素</td>\\n<td>被删除的元素</td>\\n</tr>\\n<tr>\\n<td><code>unshift()</code></td>\\n<td>向数组开头添加一个/多个元素</td>\\n<td>新长度</td>\\n</tr>\\n<tr>\\n<td><code>shift()</code></td>\\n<td>删除数组第一个元素</td>\\n<td>被删除的元素</td>\\n</tr>\\n<tr>\\n<td><code>splice()</code></td>\\n<td>从指定位置删除/插入元素</td>\\n<td>被删除元素组成的数组</td>\\n</tr>\\n<tr>\\n<td><code>sort()</code></td>\\n<td>对数组元素排序</td>\\n<td>排序后的原数组</td>\\n</tr>\\n<tr>\\n<td><code>reverse()</code></td>\\n<td>反转数组元素顺序</td>\\n<td>反转后的原数组</td>\\n</tr>\\n<tr>\\n<td><code>fill()</code></td>\\n<td>用指定值填充数组</td>\\n<td>修改后的原数组</td>\\n</tr>\\n</tbody>\\n</table>\",\"autoDesc\":true}")
export { comp, data }

if (import.meta.webpackHot) {
  import.meta.webpackHot.accept()
  if (__VUE_HMR_RUNTIME__.updatePageData) {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  }
}

if (import.meta.hot) {
  import.meta.hot.accept(({ data }) => {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  })
}
