<template><div><h1 id="javascript-知识点" tabindex="-1"><a class="header-anchor" href="#javascript-知识点"><span>JavaScript 知识点</span></a></h1>
<h3 id="核心概念" tabindex="-1"><a class="header-anchor" href="#核心概念"><span>核心概念</span></a></h3>
<ul>
<li><RouteLink to="/frontend/javascript/prototype-chain.html">原型链</RouteLink> - JavaScript 继承机制的底层原理</li>
<li><RouteLink to="/frontend/javascript/garbage-collection.html">垃圾回收机制</RouteLink> - JavaScript 内存管理与垃圾回收算法</li>
</ul>
<h3 id="异步编程" tabindex="-1"><a class="header-anchor" href="#异步编程"><span>异步编程</span></a></h3>
<ul>
<li><RouteLink to="/frontend/javascript/callback-hell.html">回调地狱</RouteLink> - 回调地狱的危害与解决方案（Promise、async/await）</li>
</ul>
<h3 id="性能优化" tabindex="-1"><a class="header-anchor" href="#性能优化"><span>性能优化</span></a></h3>
<ul>
<li><RouteLink to="/frontend/javascript/debounce-throttle.html">防抖和节流</RouteLink> - 控制高频事件触发频率的优化技术</li>
</ul>
<h3 id="数组操作" tabindex="-1"><a class="header-anchor" href="#数组操作"><span>数组操作</span></a></h3>
<ul>
<li><RouteLink to="/frontend/javascript/array-methods.html">常见的数组方法</RouteLink> - JavaScript 数组方法完整指南</li>
</ul>
<h3 id="手写系列" tabindex="-1"><a class="header-anchor" href="#手写系列"><span>手写系列</span></a></h3>
<ul>
<li><RouteLink to="/frontend/javascript/call-apply-bind.html">手写 call/apply/bind</RouteLink> - 改变函数 this 指向的三种方法</li>
<li><RouteLink to="/frontend/javascript/array-deduplication.html">对象数组去重</RouteLink> - 包含数组属性的对象数组去重方法</li>
</ul>
<hr>
<blockquote>
<p>持续更新中...</p>
</blockquote>
</div></template>


