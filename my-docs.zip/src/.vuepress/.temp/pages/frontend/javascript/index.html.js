import comp from "D:/vue-theme-hope/my-docs/src/.vuepress/.temp/pages/frontend/javascript/index.html.vue"
const data = JSON.parse("{\"path\":\"/frontend/javascript/\",\"title\":\"JavaScript\",\"lang\":\"zh-CN\",\"frontmatter\":{\"title\":\"JavaScript\",\"icon\":\"logos:javascript\",\"description\":\"JavaScript 知识点 核心概念 - JavaScript 继承机制的底层原理 - JavaScript 内存管理与垃圾回收算法 异步编程 - 回调地狱的危害与解决方案（Promise、async/await） 性能优化 - 控制高频事件触发频率的优化技术 数组操作 - JavaScript 数组方法完整指南 手写系列 - 改变函数 this 指...\",\"head\":[[\"script\",{\"type\":\"application/ld+json\"},\"{\\\"@context\\\":\\\"https://schema.org\\\",\\\"@type\\\":\\\"Article\\\",\\\"headline\\\":\\\"JavaScript\\\",\\\"image\\\":[\\\"\\\"],\\\"dateModified\\\":null,\\\"author\\\":[{\\\"@type\\\":\\\"Person\\\",\\\"name\\\":\\\"小兔子乖乖\\\",\\\"url\\\":\\\"https://mister-hope.com\\\"}]}\"],[\"meta\",{\"property\":\"og:url\",\"content\":\"https://mister-hope.github.io/xtzgg.Blog/frontend/javascript/\"}],[\"meta\",{\"property\":\"og:site_name\",\"content\":\"小兔子乖乖\"}],[\"meta\",{\"property\":\"og:title\",\"content\":\"JavaScript\"}],[\"meta\",{\"property\":\"og:description\",\"content\":\"JavaScript 知识点 核心概念 - JavaScript 继承机制的底层原理 - JavaScript 内存管理与垃圾回收算法 异步编程 - 回调地狱的危害与解决方案（Promise、async/await） 性能优化 - 控制高频事件触发频率的优化技术 数组操作 - JavaScript 数组方法完整指南 手写系列 - 改变函数 this 指...\"}],[\"meta\",{\"property\":\"og:type\",\"content\":\"article\"}],[\"meta\",{\"property\":\"og:locale\",\"content\":\"zh-CN\"}]]},\"readingTime\":{\"minutes\":0.57,\"words\":171},\"filePathRelative\":\"frontend/javascript/README.md\",\"excerpt\":\"\\n<h3>核心概念</h3>\\n<ul>\\n<li><a href=\\\"/xtzgg.Blog/frontend/javascript/prototype-chain.html\\\" target=\\\"_blank\\\">原型链</a> - JavaScript 继承机制的底层原理</li>\\n<li><a href=\\\"/xtzgg.Blog/frontend/javascript/garbage-collection.html\\\" target=\\\"_blank\\\">垃圾回收机制</a> - JavaScript 内存管理与垃圾回收算法</li>\\n</ul>\\n<h3>异步编程</h3>\\n<ul>\\n<li><a href=\\\"/xtzgg.Blog/frontend/javascript/callback-hell.html\\\" target=\\\"_blank\\\">回调地狱</a> - 回调地狱的危害与解决方案（Promise、async/await）</li>\\n</ul>\",\"autoDesc\":true}")
export { comp, data }

if (import.meta.webpackHot) {
  import.meta.webpackHot.accept()
  if (__VUE_HMR_RUNTIME__.updatePageData) {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  }
}

if (import.meta.hot) {
  import.meta.hot.accept(({ data }) => {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  })
}
