<template><div><h1 id="前端知识点" tabindex="-1"><a class="header-anchor" href="#前端知识点"><span>前端知识点</span></a></h1>
<p>欢迎来到前端知识点专区！这里收集了前端开发相关的各种技术知识。</p>
<h2 id="📚-知识分类" tabindex="-1"><a class="header-anchor" href="#📚-知识分类"><span>📚 知识分类</span></a></h2>
<h3 id="javascript-基础" tabindex="-1"><a class="header-anchor" href="#javascript-基础"><span>JavaScript 基础</span></a></h3>
<ul>
<li>数据类型</li>
<li>原型链</li>
<li>闭包</li>
<li>异步编程</li>
</ul>
<h3 id="框架相关" tabindex="-1"><a class="header-anchor" href="#框架相关"><span>框架相关</span></a></h3>
<ul>
<li>Vue.js</li>
<li>React</li>
<li>构建工具</li>
</ul>
<h3 id="工程化" tabindex="-1"><a class="header-anchor" href="#工程化"><span>工程化</span></a></h3>
<ul>
<li>Webpack</li>
<li>Vite</li>
<li>模块化</li>
</ul>
<h3 id="浏览器相关" tabindex="-1"><a class="header-anchor" href="#浏览器相关"><span>浏览器相关</span></a></h3>
<ul>
<li>DOM 操作</li>
<li>事件机制</li>
<li>性能优化</li>
</ul>
<hr>
<blockquote>
<p>持续更新中...</p>
</blockquote>
</div></template>


