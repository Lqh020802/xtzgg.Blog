import comp from "D:/vue-theme-hope/my-docs/src/.vuepress/.temp/pages/frontend/index.html.vue"
const data = JSON.parse("{\"path\":\"/frontend/\",\"title\":\"前端知识点\",\"lang\":\"zh-CN\",\"frontmatter\":{\"title\":\"前端知识点\",\"icon\":\"mdi:code-braces\",\"description\":\"前端知识点 欢迎来到前端知识点专区！这里收集了前端开发相关的各种技术知识。 📚 知识分类 JavaScript 基础 数据类型 原型链 闭包 异步编程 框架相关 Vue.js React 构建工具 工程化 Webpack Vite 模块化 浏览器相关 DOM 操作 事件机制 性能优化 持续更新中...\",\"head\":[[\"script\",{\"type\":\"application/ld+json\"},\"{\\\"@context\\\":\\\"https://schema.org\\\",\\\"@type\\\":\\\"Article\\\",\\\"headline\\\":\\\"前端知识点\\\",\\\"image\\\":[\\\"\\\"],\\\"dateModified\\\":null,\\\"author\\\":[{\\\"@type\\\":\\\"Person\\\",\\\"name\\\":\\\"小兔子乖乖\\\",\\\"url\\\":\\\"https://mister-hope.com\\\"}]}\"],[\"meta\",{\"property\":\"og:url\",\"content\":\"https://mister-hope.github.io/xtzgg.Blog/frontend/\"}],[\"meta\",{\"property\":\"og:site_name\",\"content\":\"小兔子乖乖\"}],[\"meta\",{\"property\":\"og:title\",\"content\":\"前端知识点\"}],[\"meta\",{\"property\":\"og:description\",\"content\":\"前端知识点 欢迎来到前端知识点专区！这里收集了前端开发相关的各种技术知识。 📚 知识分类 JavaScript 基础 数据类型 原型链 闭包 异步编程 框架相关 Vue.js React 构建工具 工程化 Webpack Vite 模块化 浏览器相关 DOM 操作 事件机制 性能优化 持续更新中...\"}],[\"meta\",{\"property\":\"og:type\",\"content\":\"article\"}],[\"meta\",{\"property\":\"og:locale\",\"content\":\"zh-CN\"}]]},\"readingTime\":{\"minutes\":0.35,\"words\":104},\"filePathRelative\":\"frontend/README.md\",\"excerpt\":\"\\n<p>欢迎来到前端知识点专区！这里收集了前端开发相关的各种技术知识。</p>\\n<h2>📚 知识分类</h2>\\n<h3>JavaScript 基础</h3>\\n<ul>\\n<li>数据类型</li>\\n<li>原型链</li>\\n<li>闭包</li>\\n<li>异步编程</li>\\n</ul>\\n<h3>框架相关</h3>\\n<ul>\\n<li>Vue.js</li>\\n<li>React</li>\\n<li>构建工具</li>\\n</ul>\\n<h3>工程化</h3>\\n<ul>\\n<li>Webpack</li>\\n<li>Vite</li>\\n<li>模块化</li>\\n</ul>\\n<h3>浏览器相关</h3>\\n<ul>\\n<li>DOM 操作</li>\\n<li>事件机制</li>\\n<li>性能优化</li>\\n</ul>\",\"autoDesc\":true}")
export { comp, data }

if (import.meta.webpackHot) {
  import.meta.webpackHot.accept()
  if (__VUE_HMR_RUNTIME__.updatePageData) {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  }
}

if (import.meta.hot) {
  import.meta.hot.accept(({ data }) => {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  })
}
