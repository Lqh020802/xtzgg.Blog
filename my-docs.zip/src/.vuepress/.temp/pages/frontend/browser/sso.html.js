import comp from "D:/vue-theme-hope/my-docs/src/.vuepress/.temp/pages/frontend/browser/sso.html.vue"
const data = JSON.parse("{\"path\":\"/frontend/browser/sso.html\",\"title\":\"单点登录 (SSO)\",\"lang\":\"zh-CN\",\"frontmatter\":{\"title\":\"单点登录 (SSO)\",\"icon\":\"mdi:web\",\"description\":\"单点登录 (SSO) 1. 什么是单点登录 单点登录（SSO，Single Sign-On） 是一种身份认证机制，允许用户只需一次登录，即可访问多个相互信任的应用系统，无需重复输入账号密码。 1.1 应用场景 典型场景： 企业内部系统（OA、CRM、邮箱、考勤系统等） 互联网平台（淘宝、天猫、支付宝共享登录） Google 服务（Gmail、YouTu...\",\"head\":[[\"script\",{\"type\":\"application/ld+json\"},\"{\\\"@context\\\":\\\"https://schema.org\\\",\\\"@type\\\":\\\"Article\\\",\\\"headline\\\":\\\"单点登录 (SSO)\\\",\\\"image\\\":[\\\"\\\"],\\\"dateModified\\\":null,\\\"author\\\":[{\\\"@type\\\":\\\"Person\\\",\\\"name\\\":\\\"小兔子乖乖\\\",\\\"url\\\":\\\"https://mister-hope.com\\\"}]}\"],[\"meta\",{\"property\":\"og:url\",\"content\":\"https://mister-hope.github.io/xtzgg.Blog/frontend/browser/sso.html\"}],[\"meta\",{\"property\":\"og:site_name\",\"content\":\"小兔子乖乖\"}],[\"meta\",{\"property\":\"og:title\",\"content\":\"单点登录 (SSO)\"}],[\"meta\",{\"property\":\"og:description\",\"content\":\"单点登录 (SSO) 1. 什么是单点登录 单点登录（SSO，Single Sign-On） 是一种身份认证机制，允许用户只需一次登录，即可访问多个相互信任的应用系统，无需重复输入账号密码。 1.1 应用场景 典型场景： 企业内部系统（OA、CRM、邮箱、考勤系统等） 互联网平台（淘宝、天猫、支付宝共享登录） Google 服务（Gmail、YouTu...\"}],[\"meta\",{\"property\":\"og:type\",\"content\":\"article\"}],[\"meta\",{\"property\":\"og:locale\",\"content\":\"zh-CN\"}]]},\"readingTime\":{\"minutes\":9.71,\"words\":2913},\"filePathRelative\":\"frontend/browser/sso.md\",\"excerpt\":\"\\n<h2>1. 什么是单点登录</h2>\\n<p><strong>单点登录（SSO，Single Sign-On）</strong> 是一种身份认证机制，允许用户<strong>只需一次登录，即可访问多个相互信任的应用系统</strong>，无需重复输入账号密码。</p>\\n<h3>1.1 应用场景</h3>\\n<p><strong>典型场景：</strong></p>\\n<ul>\\n<li>企业内部系统（OA、CRM、邮箱、考勤系统等）</li>\\n<li>互联网平台（淘宝、天猫、支付宝共享登录）</li>\\n<li>Google 服务（Gmail、YouTube、Google Drive 等）</li>\\n</ul>\",\"autoDesc\":true}")
export { comp, data }

if (import.meta.webpackHot) {
  import.meta.webpackHot.accept()
  if (__VUE_HMR_RUNTIME__.updatePageData) {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  }
}

if (import.meta.hot) {
  import.meta.hot.accept(({ data }) => {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  })
}
