import comp from "D:/vue-theme-hope/my-docs/src/.vuepress/.temp/pages/frontend/browser/process-model.html.vue"
const data = JSON.parse("{\"path\":\"/frontend/browser/process-model.html\",\"title\":\"浏览器进程模型\",\"lang\":\"zh-CN\",\"frontmatter\":{\"title\":\"浏览器进程模型\",\"icon\":\"mdi:web\",\"description\":\"浏览器进程模型 1. 进程（Process） 1.1 什么是进程 进程可以理解为一块内存空间，操作系统为每个应用程序分配独立的内存区域。 1.2 进程的特点 独立性 ✅ 各个应用程序之间的进程相互独立 ✅ 一个进程崩溃不会影响其他进程 ✅ 提高系统稳定性和安全性 进程间通信（IPC） 不同的进程间进行通信，需要双方的同意 2. 线程（Thread） 2...\",\"head\":[[\"script\",{\"type\":\"application/ld+json\"},\"{\\\"@context\\\":\\\"https://schema.org\\\",\\\"@type\\\":\\\"Article\\\",\\\"headline\\\":\\\"浏览器进程模型\\\",\\\"image\\\":[\\\"https://mister-hope.github.io/xtzgg.Blog/assets/images/javascript/event-loop.png\\\"],\\\"dateModified\\\":null,\\\"author\\\":[{\\\"@type\\\":\\\"Person\\\",\\\"name\\\":\\\"小兔子乖乖\\\",\\\"url\\\":\\\"https://mister-hope.com\\\"}]}\"],[\"meta\",{\"property\":\"og:url\",\"content\":\"https://mister-hope.github.io/xtzgg.Blog/frontend/browser/process-model.html\"}],[\"meta\",{\"property\":\"og:site_name\",\"content\":\"小兔子乖乖\"}],[\"meta\",{\"property\":\"og:title\",\"content\":\"浏览器进程模型\"}],[\"meta\",{\"property\":\"og:description\",\"content\":\"浏览器进程模型 1. 进程（Process） 1.1 什么是进程 进程可以理解为一块内存空间，操作系统为每个应用程序分配独立的内存区域。 1.2 进程的特点 独立性 ✅ 各个应用程序之间的进程相互独立 ✅ 一个进程崩溃不会影响其他进程 ✅ 提高系统稳定性和安全性 进程间通信（IPC） 不同的进程间进行通信，需要双方的同意 2. 线程（Thread） 2...\"}],[\"meta\",{\"property\":\"og:type\",\"content\":\"article\"}],[\"meta\",{\"property\":\"og:image\",\"content\":\"https://mister-hope.github.io/xtzgg.Blog/assets/images/javascript/event-loop.png\"}],[\"meta\",{\"property\":\"og:locale\",\"content\":\"zh-CN\"}]]},\"readingTime\":{\"minutes\":13.57,\"words\":4070},\"filePathRelative\":\"frontend/browser/process-model.md\",\"excerpt\":\"\\n<h2>1. 进程（Process）</h2>\\n<h3>1.1 什么是进程</h3>\\n<p><strong>进程可以理解为一块内存空间</strong>，操作系统为每个应用程序分配独立的内存区域。</p>\\n<h3>1.2 进程的特点</h3>\\n<h4>独立性</h4>\\n<div class=\\\"language- line-numbers-mode\\\" data-highlighter=\\\"shiki\\\" data-ext=\\\"\\\" style=\\\"--shiki-light:#383A42;--shiki-dark:#abb2bf;--shiki-light-bg:#FAFAFA;--shiki-dark-bg:#282c34\\\"><pre class=\\\"shiki shiki-themes one-light one-dark-pro vp-code\\\"><code class=\\\"language-\\\"><span class=\\\"line\\\"><span>应用程序 A 的进程 ←→ 独立内存空间</span></span>\\n<span class=\\\"line\\\"><span>应用程序 B 的进程 ←→ 独立内存空间</span></span>\\n<span class=\\\"line\\\"><span>应用程序 C 的进程 ←→ 独立内存空间</span></span></code></pre>\\n<div class=\\\"line-numbers\\\" aria-hidden=\\\"true\\\" style=\\\"counter-reset:line-number 0\\\"><div class=\\\"line-number\\\"></div><div class=\\\"line-number\\\"></div><div class=\\\"line-number\\\"></div></div></div>\",\"autoDesc\":true}")
export { comp, data }

if (import.meta.webpackHot) {
  import.meta.webpackHot.accept()
  if (__VUE_HMR_RUNTIME__.updatePageData) {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  }
}

if (import.meta.hot) {
  import.meta.hot.accept(({ data }) => {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  })
}
