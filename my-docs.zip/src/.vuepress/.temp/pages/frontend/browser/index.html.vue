<template><div><h1 id="浏览器相关知识" tabindex="-1"><a class="header-anchor" href="#浏览器相关知识"><span>浏览器相关知识</span></a></h1>
<h3 id="浏览器原理" tabindex="-1"><a class="header-anchor" href="#浏览器原理"><span>浏览器原理</span></a></h3>
<ul>
<li><RouteLink to="/frontend/browser/process-model.html">浏览器进程模型</RouteLink> - 进程与线程、事件循环、异步任务的原理</li>
</ul>
<h3 id="网络与安全" tabindex="-1"><a class="header-anchor" href="#网络与安全"><span>网络与安全</span></a></h3>
<ul>
<li><RouteLink to="/frontend/browser/jwt.html">JWT 身份认证</RouteLink> - JSON Web Token 的工作原理与最佳实践</li>
<li><RouteLink to="/frontend/browser/sso.html">单点登录 (SSO)</RouteLink> - 单点登录的实现原理与三种模式对比</li>
<li><RouteLink to="/frontend/browser/xss.html">XSS 攻击与防护</RouteLink> - 跨站脚本攻击的原理、危害与完整防护方案</li>
</ul>
<blockquote>
<p>持续更新中...</p>
</blockquote>
</div></template>


