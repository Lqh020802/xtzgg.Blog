import comp from "D:/vue-theme-hope/my-docs/src/.vuepress/.temp/pages/frontend/browser/xss.html.vue"
const data = JSON.parse("{\"path\":\"/frontend/browser/xss.html\",\"title\":\"XSS 攻击与防护\",\"lang\":\"zh-CN\",\"frontmatter\":{\"title\":\"XSS 攻击与防护\",\"icon\":\"mdi:web\",\"description\":\"XSS 攻击与防护 1. 什么是 XSS 攻击 XSS（Cross-Site Scripting，跨站脚本攻击） 是一种常见的前端安全漏洞，指攻击者将恶意 JavaScript 代码注入到网页中，当用户访问该网页时，恶意代码会被浏览器执行，从而： 🔓 窃取用户数据（Cookie、Token、敏感信息） 🎭 伪造用户操作（转账、发布内容、修改密码） ...\",\"head\":[[\"script\",{\"type\":\"application/ld+json\"},\"{\\\"@context\\\":\\\"https://schema.org\\\",\\\"@type\\\":\\\"Article\\\",\\\"headline\\\":\\\"XSS 攻击与防护\\\",\\\"image\\\":[\\\"\\\"],\\\"dateModified\\\":null,\\\"author\\\":[{\\\"@type\\\":\\\"Person\\\",\\\"name\\\":\\\"小兔子乖乖\\\",\\\"url\\\":\\\"https://mister-hope.com\\\"}]}\"],[\"meta\",{\"property\":\"og:url\",\"content\":\"https://mister-hope.github.io/xtzgg.Blog/frontend/browser/xss.html\"}],[\"meta\",{\"property\":\"og:site_name\",\"content\":\"小兔子乖乖\"}],[\"meta\",{\"property\":\"og:title\",\"content\":\"XSS 攻击与防护\"}],[\"meta\",{\"property\":\"og:description\",\"content\":\"XSS 攻击与防护 1. 什么是 XSS 攻击 XSS（Cross-Site Scripting，跨站脚本攻击） 是一种常见的前端安全漏洞，指攻击者将恶意 JavaScript 代码注入到网页中，当用户访问该网页时，恶意代码会被浏览器执行，从而： 🔓 窃取用户数据（Cookie、Token、敏感信息） 🎭 伪造用户操作（转账、发布内容、修改密码） ...\"}],[\"meta\",{\"property\":\"og:type\",\"content\":\"article\"}],[\"meta\",{\"property\":\"og:locale\",\"content\":\"zh-CN\"}]]},\"readingTime\":{\"minutes\":10.89,\"words\":3266},\"filePathRelative\":\"frontend/browser/xss.md\",\"excerpt\":\"\\n<h2>1. 什么是 XSS 攻击</h2>\\n<p><strong>XSS（Cross-Site Scripting，跨站脚本攻击）</strong> 是一种常见的前端安全漏洞，指攻击者将恶意 JavaScript 代码注入到网页中，当用户访问该网页时，恶意代码会被浏览器执行，从而：</p>\\n<ul>\\n<li>🔓 <strong>窃取用户数据</strong>（Cookie、Token、敏感信息）</li>\\n<li>🎭 <strong>伪造用户操作</strong>（转账、发布内容、修改密码）</li>\\n<li>💥 <strong>破坏页面功能</strong>（篡改页面、删除内容）</li>\\n</ul>\",\"autoDesc\":true}")
export { comp, data }

if (import.meta.webpackHot) {
  import.meta.webpackHot.accept()
  if (__VUE_HMR_RUNTIME__.updatePageData) {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  }
}

if (import.meta.hot) {
  import.meta.hot.accept(({ data }) => {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  })
}
