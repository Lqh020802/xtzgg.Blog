import comp from "D:/vue-theme-hope/my-docs/src/.vuepress/.temp/pages/frontend/browser/index.html.vue"
const data = JSON.parse("{\"path\":\"/frontend/browser/\",\"title\":\"浏览器相关\",\"lang\":\"zh-CN\",\"frontmatter\":{\"title\":\"浏览器相关\",\"icon\":\"mdi:web\",\"description\":\"浏览器相关知识 浏览器原理 - 进程与线程、事件循环、异步任务的原理 网络与安全 - JSON Web Token 的工作原理与最佳实践 - 单点登录的实现原理与三种模式对比 - 跨站脚本攻击的原理、危害与完整防护方案 持续更新中...\",\"head\":[[\"script\",{\"type\":\"application/ld+json\"},\"{\\\"@context\\\":\\\"https://schema.org\\\",\\\"@type\\\":\\\"Article\\\",\\\"headline\\\":\\\"浏览器相关\\\",\\\"image\\\":[\\\"\\\"],\\\"dateModified\\\":null,\\\"author\\\":[{\\\"@type\\\":\\\"Person\\\",\\\"name\\\":\\\"小兔子乖乖\\\",\\\"url\\\":\\\"https://mister-hope.com\\\"}]}\"],[\"meta\",{\"property\":\"og:url\",\"content\":\"https://mister-hope.github.io/xtzgg.Blog/frontend/browser/\"}],[\"meta\",{\"property\":\"og:site_name\",\"content\":\"小兔子乖乖\"}],[\"meta\",{\"property\":\"og:title\",\"content\":\"浏览器相关\"}],[\"meta\",{\"property\":\"og:description\",\"content\":\"浏览器相关知识 浏览器原理 - 进程与线程、事件循环、异步任务的原理 网络与安全 - JSON Web Token 的工作原理与最佳实践 - 单点登录的实现原理与三种模式对比 - 跨站脚本攻击的原理、危害与完整防护方案 持续更新中...\"}],[\"meta\",{\"property\":\"og:type\",\"content\":\"article\"}],[\"meta\",{\"property\":\"og:locale\",\"content\":\"zh-CN\"}]]},\"readingTime\":{\"minutes\":0.41,\"words\":123},\"filePathRelative\":\"frontend/browser/README.md\",\"excerpt\":\"\\n<h3>浏览器原理</h3>\\n<ul>\\n<li><a href=\\\"/xtzgg.Blog/frontend/browser/process-model.html\\\" target=\\\"_blank\\\">浏览器进程模型</a> - 进程与线程、事件循环、异步任务的原理</li>\\n</ul>\\n<h3>网络与安全</h3>\\n<ul>\\n<li><a href=\\\"/xtzgg.Blog/frontend/browser/jwt.html\\\" target=\\\"_blank\\\">JWT 身份认证</a> - JSON Web Token 的工作原理与最佳实践</li>\\n<li><a href=\\\"/xtzgg.Blog/frontend/browser/sso.html\\\" target=\\\"_blank\\\">单点登录 (SSO)</a> - 单点登录的实现原理与三种模式对比</li>\\n<li><a href=\\\"/xtzgg.Blog/frontend/browser/xss.html\\\" target=\\\"_blank\\\">XSS 攻击与防护</a> - 跨站脚本攻击的原理、危害与完整防护方案</li>\\n</ul>\",\"autoDesc\":true}")
export { comp, data }

if (import.meta.webpackHot) {
  import.meta.webpackHot.accept()
  if (__VUE_HMR_RUNTIME__.updatePageData) {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  }
}

if (import.meta.hot) {
  import.meta.hot.accept(({ data }) => {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  })
}
