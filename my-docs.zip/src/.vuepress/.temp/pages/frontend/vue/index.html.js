import comp from "D:/vue-theme-hope/my-docs/src/.vuepress/.temp/pages/frontend/vue/index.html.vue"
const data = JSON.parse("{\"path\":\"/frontend/vue/\",\"title\":\"Vue.js\",\"lang\":\"zh-CN\",\"frontmatter\":{\"title\":\"Vue.js\",\"icon\":\"logos:vue\",\"description\":\"Vue.js 知识点 Vue3 新特性 - Vue3 组合式 API 与 Vue2 Mixin 的对比 Vue 基础 核心概念 响应式原理 虚拟 DOM 数据绑定 指令系统 组件开发 组件注册 Props 传递 事件通信 插槽使用 生命周期 创建阶段 挂载阶段 更新阶段 销毁阶段 Vue 3 新特性 Composition API setup 函数 r...\",\"head\":[[\"script\",{\"type\":\"application/ld+json\"},\"{\\\"@context\\\":\\\"https://schema.org\\\",\\\"@type\\\":\\\"Article\\\",\\\"headline\\\":\\\"Vue.js\\\",\\\"image\\\":[\\\"\\\"],\\\"dateModified\\\":null,\\\"author\\\":[{\\\"@type\\\":\\\"Person\\\",\\\"name\\\":\\\"小兔子乖乖\\\",\\\"url\\\":\\\"https://mister-hope.com\\\"}]}\"],[\"meta\",{\"property\":\"og:url\",\"content\":\"https://mister-hope.github.io/xtzgg.Blog/frontend/vue/\"}],[\"meta\",{\"property\":\"og:site_name\",\"content\":\"小兔子乖乖\"}],[\"meta\",{\"property\":\"og:title\",\"content\":\"Vue.js\"}],[\"meta\",{\"property\":\"og:description\",\"content\":\"Vue.js 知识点 Vue3 新特性 - Vue3 组合式 API 与 Vue2 Mixin 的对比 Vue 基础 核心概念 响应式原理 虚拟 DOM 数据绑定 指令系统 组件开发 组件注册 Props 传递 事件通信 插槽使用 生命周期 创建阶段 挂载阶段 更新阶段 销毁阶段 Vue 3 新特性 Composition API setup 函数 r...\"}],[\"meta\",{\"property\":\"og:type\",\"content\":\"article\"}],[\"meta\",{\"property\":\"og:locale\",\"content\":\"zh-CN\"}]]},\"readingTime\":{\"minutes\":0.53,\"words\":159},\"filePathRelative\":\"frontend/vue/README.md\",\"excerpt\":\"\\n<h3>Vue3 新特性</h3>\\n<ul>\\n<li><a href=\\\"/xtzgg.Blog/frontend/vue/hook-vs-mixin.html\\\" target=\\\"_blank\\\">Hook 与 Mixin</a> - Vue3 组合式 API 与 Vue2 Mixin 的对比</li>\\n</ul>\\n<h2>Vue 基础</h2>\\n<h3>核心概念</h3>\\n<ul>\\n<li>响应式原理</li>\\n<li>虚拟 DOM</li>\\n<li>数据绑定</li>\\n<li>指令系统</li>\\n</ul>\\n<h3>组件开发</h3>\\n<ul>\\n<li>组件注册</li>\\n<li>Props 传递</li>\\n<li>事件通信</li>\\n<li>插槽使用</li>\\n</ul>\",\"autoDesc\":true}")
export { comp, data }

if (import.meta.webpackHot) {
  import.meta.webpackHot.accept()
  if (__VUE_HMR_RUNTIME__.updatePageData) {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  }
}

if (import.meta.hot) {
  import.meta.hot.accept(({ data }) => {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  })
}
