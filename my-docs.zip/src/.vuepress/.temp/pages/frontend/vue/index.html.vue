<template><div><h1 id="vue-js-知识点" tabindex="-1"><a class="header-anchor" href="#vue-js-知识点"><span>Vue.js 知识点</span></a></h1>
<h3 id="vue3-新特性" tabindex="-1"><a class="header-anchor" href="#vue3-新特性"><span>Vue3 新特性</span></a></h3>
<ul>
<li><RouteLink to="/frontend/vue/hook-vs-mixin.html">Hook 与 Mixin</RouteLink> - Vue3 组合式 API 与 Vue2 Mixin 的对比</li>
</ul>
<h2 id="vue-基础" tabindex="-1"><a class="header-anchor" href="#vue-基础"><span>Vue 基础</span></a></h2>
<h3 id="核心概念" tabindex="-1"><a class="header-anchor" href="#核心概念"><span>核心概念</span></a></h3>
<ul>
<li>响应式原理</li>
<li>虚拟 DOM</li>
<li>数据绑定</li>
<li>指令系统</li>
</ul>
<h3 id="组件开发" tabindex="-1"><a class="header-anchor" href="#组件开发"><span>组件开发</span></a></h3>
<ul>
<li>组件注册</li>
<li>Props 传递</li>
<li>事件通信</li>
<li>插槽使用</li>
</ul>
<h3 id="生命周期" tabindex="-1"><a class="header-anchor" href="#生命周期"><span>生命周期</span></a></h3>
<ul>
<li>创建阶段</li>
<li>挂载阶段</li>
<li>更新阶段</li>
<li>销毁阶段</li>
</ul>
<h2 id="vue-3-新特性" tabindex="-1"><a class="header-anchor" href="#vue-3-新特性"><span>Vue 3 新特性</span></a></h2>
<h3 id="composition-api" tabindex="-1"><a class="header-anchor" href="#composition-api"><span>Composition API</span></a></h3>
<ul>
<li>setup 函数</li>
<li>ref 和 reactive</li>
<li>computed 和 watch</li>
<li>生命周期钩子</li>
</ul>
<h3 id="性能优化" tabindex="-1"><a class="header-anchor" href="#性能优化"><span>性能优化</span></a></h3>
<ul>
<li>Tree-shaking</li>
<li>Teleport</li>
<li>Suspense</li>
<li>Fragment</li>
</ul>
<h2 id="生态工具" tabindex="-1"><a class="header-anchor" href="#生态工具"><span>生态工具</span></a></h2>
<h3 id="vue-router" tabindex="-1"><a class="header-anchor" href="#vue-router"><span>Vue Router</span></a></h3>
<ul>
<li>路由配置</li>
<li>导航守卫</li>
<li>动态路由</li>
</ul>
<h3 id="pinia-vuex" tabindex="-1"><a class="header-anchor" href="#pinia-vuex"><span>Pinia/Vuex</span></a></h3>
<ul>
<li>状态管理</li>
<li>模块化</li>
<li>插件机制</li>
</ul>
<hr>
<blockquote>
<p>持续更新中...</p>
</blockquote>
</div></template>


