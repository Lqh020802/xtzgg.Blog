import comp from "D:/vue-theme-hope/my-docs/src/.vuepress/.temp/pages/frontend/vue/hook-vs-mixin.html.vue"
const data = JSON.parse("{\"path\":\"/frontend/vue/hook-vs-mixin.html\",\"title\":\"Vue3 Hook 与 Vue2 Mixin\",\"lang\":\"zh-CN\",\"frontmatter\":{\"title\":\"Vue3 Hook 与 Vue2 Mixin\",\"icon\":\"logos:vue\",\"description\":\"Vue3 Hook 与 Vue2 Mixin 在 Vue3 中，hook（钩子函数） 是一种基于组合式 API 的代码复用机制，替代 Vue2 中的 mixin，专为 Vue3 的响应式系统和组件生命周期设计。它允许将组件逻辑抽离为可复用的函数，提高代码的可维护性和复用性。 1. 什么是 Hook Vue3 的 hook 本质上是一个自定义函数，通常以...\",\"head\":[[\"script\",{\"type\":\"application/ld+json\"},\"{\\\"@context\\\":\\\"https://schema.org\\\",\\\"@type\\\":\\\"Article\\\",\\\"headline\\\":\\\"Vue3 Hook 与 Vue2 Mixin\\\",\\\"image\\\":[\\\"\\\"],\\\"dateModified\\\":null,\\\"author\\\":[{\\\"@type\\\":\\\"Person\\\",\\\"name\\\":\\\"小兔子乖乖\\\",\\\"url\\\":\\\"https://mister-hope.com\\\"}]}\"],[\"meta\",{\"property\":\"og:url\",\"content\":\"https://mister-hope.github.io/xtzgg.Blog/frontend/vue/hook-vs-mixin.html\"}],[\"meta\",{\"property\":\"og:site_name\",\"content\":\"小兔子乖乖\"}],[\"meta\",{\"property\":\"og:title\",\"content\":\"Vue3 Hook 与 Vue2 Mixin\"}],[\"meta\",{\"property\":\"og:description\",\"content\":\"Vue3 Hook 与 Vue2 Mixin 在 Vue3 中，hook（钩子函数） 是一种基于组合式 API 的代码复用机制，替代 Vue2 中的 mixin，专为 Vue3 的响应式系统和组件生命周期设计。它允许将组件逻辑抽离为可复用的函数，提高代码的可维护性和复用性。 1. 什么是 Hook Vue3 的 hook 本质上是一个自定义函数，通常以...\"}],[\"meta\",{\"property\":\"og:type\",\"content\":\"article\"}],[\"meta\",{\"property\":\"og:locale\",\"content\":\"zh-CN\"}]]},\"readingTime\":{\"minutes\":7.96,\"words\":2388},\"filePathRelative\":\"frontend/vue/hook-vs-mixin.md\",\"excerpt\":\"\\n<p>在 Vue3 中，<strong>hook（钩子函数）</strong> 是一种基于组合式 API 的代码复用机制，替代 Vue2 中的 mixin，专为 Vue3 的响应式系统和组件生命周期设计。它允许将组件逻辑抽离为可复用的函数，提高代码的可维护性和复用性。</p>\\n<h2>1. 什么是 Hook</h2>\\n<p><strong>Vue3 的 hook 本质上是一个自定义函数</strong>，通常以 <code>use</code> 开头（约定俗成），内部可以调用 Vue 提供的组合式 API（如 <code>ref</code>、<code>reactive</code>、<code>watch</code>、<code>onMounted</code> 等），也可以调用其他 hook。</p>\",\"autoDesc\":true}")
export { comp, data }

if (import.meta.webpackHot) {
  import.meta.webpackHot.accept()
  if (__VUE_HMR_RUNTIME__.updatePageData) {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  }
}

if (import.meta.hot) {
  import.meta.hot.accept(({ data }) => {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  })
}
