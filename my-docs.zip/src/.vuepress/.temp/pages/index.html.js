import comp from "D:/vue-theme-hope/my-docs/src/.vuepress/.temp/pages/index.html.vue"
const data = JSON.parse("{\"path\":\"/\",\"title\":\"\",\"lang\":\"zh-CN\",\"frontmatter\":{\"home\":true,\"portfolio\":true,\"name\":\"小兔子乖乖\",\"welcome\":\"👋 欢迎来到我的个人主页\",\"titles\":[\"前端开发者\",\"技术博主\",\"开源爱好者\"],\"bgImage\":\"/npc.jpg\",\"bgImageStyle\":{\"background-attachment\":\"fixed\",\"background-size\":\"cover\",\"background-position\":\"center\"},\"footer\":\"到底喽···\",\"head\":[[\"script\",{\"type\":\"application/ld+json\"},\"{\\\"@context\\\":\\\"https://schema.org\\\",\\\"@type\\\":\\\"WebPage\\\",\\\"name\\\":\\\"\\\"}\"],[\"meta\",{\"property\":\"og:url\",\"content\":\"https://mister-hope.github.io/xtzgg.Blog/\"}],[\"meta\",{\"property\":\"og:site_name\",\"content\":\"小兔子乖乖\"}],[\"meta\",{\"property\":\"og:type\",\"content\":\"website\"}],[\"meta\",{\"property\":\"og:locale\",\"content\":\"zh-CN\"}]]},\"readingTime\":{\"minutes\":0.17,\"words\":52},\"filePathRelative\":\"README.md\",\"excerpt\":\"\"}")
export { comp, data }

if (import.meta.webpackHot) {
  import.meta.webpackHot.accept()
  if (__VUE_HMR_RUNTIME__.updatePageData) {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  }
}

if (import.meta.hot) {
  import.meta.hot.accept(({ data }) => {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  })
}
