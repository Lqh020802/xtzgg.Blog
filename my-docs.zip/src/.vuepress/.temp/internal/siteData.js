export const siteData = JSON.parse("{\"base\":\"/xtzgg.Blog/\",\"lang\":\"zh-CN\",\"title\":\"小兔子乖乖\",\"description\":\"欢迎来到我的个人主页\",\"head\":[[\"meta\",{\"name\":\"application-name\",\"content\":\"小兔子乖乖\"}],[\"meta\",{\"name\":\"mobile-web-app-capable\",\"content\":\"yes\"}],[\"meta\",{\"name\":\"theme-color\",\"content\":\"#46bd87\"}],[\"meta\",{\"name\":\"apple-mobile-web-app-status-bar-style\",\"content\":\"black\"}],[\"link\",{\"rel\":\"icon\",\"href\":\"/xtzgg.Blog/favicon.ico\"}],[\"link\",{\"rel\":\"manifest\",\"href\":\"/xtzgg.Blog/manifest.webmanifest\",\"crossorigin\":\"use-credentials\"}],[\"link\",{\"rel\":\"icon\",\"href\":\"/xtzgg.Blog/logo.png\",\"type\":\"image/png\",\"sizes\":\"512x512\"}],[\"link\",{\"rel\":\"apple-touch-icon\",\"href\":\"/xtzgg.Blog/logo.png\"}]],\"locales\":{}}")

if (import.meta.webpackHot) {
  import.meta.webpackHot.accept()
  if (__VUE_HMR_RUNTIME__.updateSiteData) {
    __VUE_HMR_RUNTIME__.updateSiteData(siteData)
  }
}

if (import.meta.hot) {
  import.meta.hot.accept(({ siteData }) => {
    __VUE_HMR_RUNTIME__.updateSiteData(siteData)
  })
}
