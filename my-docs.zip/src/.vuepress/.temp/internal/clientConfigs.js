import * as clientConfig0 from 'D:/vue-theme-hope/my-docs/src/.vuepress/.temp/shiki/config.js'
import * as clientConfig1 from 'D:/vue-theme-hope/my-docs/src/.vuepress/.temp/sass-palette/load-hope.js'
import * as clientConfig2 from 'D:/vue-theme-hope/my-docs/src/.vuepress/.temp/markdown-chart/config.js'
import * as clientConfig3 from 'D:/vue-theme-hope/my-docs/src/.vuepress/.temp/markdown-ext/config.js'
import * as clientConfig4 from 'D:/vue-theme-hope/my-docs/node_modules/.pnpm/@vuepress+plugin-markdown-h_4d7c11fd78202e335af4b8e11efe032e/node_modules/@vuepress/plugin-markdown-hint/lib/client/config.js'
import * as clientConfig5 from 'D:/vue-theme-hope/my-docs/src/.vuepress/.temp/markdown-tab/config.js'
import * as clientConfig6 from 'D:/vue-theme-hope/my-docs/src/.vuepress/.temp/md-enhance/config.js'
import * as clientConfig7 from 'D:/vue-theme-hope/my-docs/src/.vuepress/.temp/markdown-image/client.js'
import * as clientConfig8 from 'D:/vue-theme-hope/my-docs/src/.vuepress/.temp/markdown-stylize/config.js'
import * as clientConfig9 from 'D:/vue-theme-hope/my-docs/node_modules/.pnpm/@vuepress+plugin-theme-data_b547ac861c5d01351b2e6711c9696918/node_modules/@vuepress/plugin-theme-data/lib/client/config.js'
import * as clientConfig10 from 'D:/vue-theme-hope/my-docs/node_modules/.pnpm/@vuepress+plugin-back-to-to_9631cf916362a29eb02b4562df849a1f/node_modules/@vuepress/plugin-back-to-top/lib/client/config.js'
import * as clientConfig11 from 'D:/vue-theme-hope/my-docs/node_modules/.pnpm/@vuepress+plugin-copy-code@_94665a9725b8a7559dde86113e517804/node_modules/@vuepress/plugin-copy-code/lib/client/config.js'
import * as clientConfig12 from 'D:/vue-theme-hope/my-docs/src/.vuepress/.temp/icon/config.js'
import * as clientConfig13 from 'D:/vue-theme-hope/my-docs/node_modules/.pnpm/@vuepress+plugin-photo-swip_4efe89342310c35fd99a0dfd720cd9ab/node_modules/@vuepress/plugin-photo-swipe/lib/client/config.js'
import * as clientConfig14 from 'D:/vue-theme-hope/my-docs/src/.vuepress/.temp/components/config.js'
import * as clientConfig15 from 'D:/vue-theme-hope/my-docs/node_modules/.pnpm/@vuepress+plugin-active-hea_2b898f4b9a2903f2d23114ac4cd5b093/node_modules/@vuepress/plugin-active-header-links/lib/client/config.js'
import * as clientConfig16 from 'D:/vue-theme-hope/my-docs/node_modules/.pnpm/@vuepress+plugin-catalog@2._65d8a64978cc3600de6fd48f32fadf72/node_modules/@vuepress/plugin-catalog/lib/client/config.js'
import * as clientConfig17 from 'D:/vue-theme-hope/my-docs/node_modules/.pnpm/@vuepress+plugin-nprogress@_53808cd42a05b8cb8ceeaedbda0f044f/node_modules/@vuepress/plugin-nprogress/lib/client/config.js'
import * as clientConfig18 from 'D:/vue-theme-hope/my-docs/src/.vuepress/.temp/pwa/config.js'
import * as clientConfig19 from 'D:/vue-theme-hope/my-docs/node_modules/.pnpm/@vuepress+plugin-slimsearch_05ee820cf3d20ad05e924fb7f3dcd543/node_modules/@vuepress/plugin-slimsearch/lib/client/config.js'
import * as clientConfig20 from 'D:/vue-theme-hope/my-docs/node_modules/.pnpm/@vuepress+plugin-redirect@2_2cd04499dfd533c1cd95aaeecca5e6f7/node_modules/@vuepress/plugin-redirect/lib/client/config.js'
import * as clientConfig21 from 'D:/vue-theme-hope/my-docs/src/.vuepress/.temp/theme-hope/config.js'

export const clientConfigs = [
  clientConfig0,
  clientConfig1,
  clientConfig2,
  clientConfig3,
  clientConfig4,
  clientConfig5,
  clientConfig6,
  clientConfig7,
  clientConfig8,
  clientConfig9,
  clientConfig10,
  clientConfig11,
  clientConfig12,
  clientConfig13,
  clientConfig14,
  clientConfig15,
  clientConfig16,
  clientConfig17,
  clientConfig18,
  clientConfig19,
  clientConfig20,
  clientConfig21,
].map((m) => m.default).filter(Boolean)
