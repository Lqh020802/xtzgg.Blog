import { hasGlobalComponent } from "D:/vue-theme-hope/my-docs/node_modules/.pnpm/@vuepress+helper@2.0.0-rc.1_c3267dd389638350ba25a862a11df911/node_modules/@vuepress/helper/lib/client/index.js";
import Badge from "D:/vue-theme-hope/my-docs/node_modules/.pnpm/vuepress-plugin-components@_a946e2a5e34513ff44b60d53ff5fdb75/node_modules/vuepress-plugin-components/lib/client/components/Badge.js";
import VPCard from "D:/vue-theme-hope/my-docs/node_modules/.pnpm/vuepress-plugin-components@_a946e2a5e34513ff44b60d53ff5fdb75/node_modules/vuepress-plugin-components/lib/client/components/VPCard.js";

import "D:/vue-theme-hope/my-docs/node_modules/.pnpm/@vuepress+helper@2.0.0-rc.1_c3267dd389638350ba25a862a11df911/node_modules/@vuepress/helper/lib/client/styles/sr-only.css";

export default {
  enhance: ({ app }) => {
    if(!hasGlobalComponent("Badge")) app.component("Badge", Badge);
    if(!hasGlobalComponent("VPCard")) app.component("VPCard", VPCard);
    
  },
  setup: () => {

  },
  rootComponents: [

  ],
};
