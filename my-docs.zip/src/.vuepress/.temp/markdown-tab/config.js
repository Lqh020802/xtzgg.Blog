import { CodeTabs } from "D:/vue-theme-hope/my-docs/node_modules/.pnpm/@vuepress+plugin-markdown-t_f4b580042246a5900696522b3cbdf004/node_modules/@vuepress/plugin-markdown-tab/lib/client/components/CodeTabs.js";
import { Tabs } from "D:/vue-theme-hope/my-docs/node_modules/.pnpm/@vuepress+plugin-markdown-t_f4b580042246a5900696522b3cbdf004/node_modules/@vuepress/plugin-markdown-tab/lib/client/components/Tabs.js";
import "D:/vue-theme-hope/my-docs/node_modules/.pnpm/@vuepress+plugin-markdown-t_f4b580042246a5900696522b3cbdf004/node_modules/@vuepress/plugin-markdown-tab/lib/client/styles/vars.css";

export default {
  enhance: ({ app }) => {
    app.component("CodeTabs", CodeTabs);
    app.component("Tabs", Tabs);
  },
};
