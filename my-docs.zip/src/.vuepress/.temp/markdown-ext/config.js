    import "D:/vue-theme-hope/my-docs/node_modules/.pnpm/@vuepress+plugin-markdown-e_81f19794696b2089c2234855a9faef88/node_modules/@vuepress/plugin-markdown-ext/lib/client/styles/footnote.css"
    import "D:/vue-theme-hope/my-docs/node_modules/.pnpm/@vuepress+plugin-markdown-e_81f19794696b2089c2234855a9faef88/node_modules/@vuepress/plugin-markdown-ext/lib/client/styles/tasklist.css"
