import "D:/vue-theme-hope/my-docs/node_modules/.pnpm/@vuepress+plugin-markdown-i_01b07dc54571998b00c305567a1fd355/node_modules/@vuepress/plugin-markdown-image/lib/client/styles/figure.css"

