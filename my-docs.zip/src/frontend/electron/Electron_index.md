---
title: Electron介绍
icon: simple-icons:electron
---

# Electron介绍




### Electron介绍是什么?



***Electron***是一个使用**JavaScript**、**HTML**和**CSS**构建桌面应用程序的框架。 嵌入**Chromium**和**Node.js**到 二进制的**Electron**允许您保持一个**JavaScript**代码代码库并创建 在**Windows**上运行的跨平台应用**macOS**和**Linux**——不需要本地开发经验。