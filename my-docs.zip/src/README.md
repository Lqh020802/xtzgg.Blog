---
home: true
portfolio: true
name: 小兔子乖乖
welcome: 👋 欢迎来到我的个人主页
titles:
  - 前端开发者
  - 技术博主
  - 开源爱好者
bgImage: /npc.jpg
bgImageStyle:
  background-attachment: fixed
  background-size: cover
  background-position: center
footer: 到底喽···
---
